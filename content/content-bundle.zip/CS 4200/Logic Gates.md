## Introduction

---
0 = No digital signal
1 = digital signal

![[Pasted image 20230830114951.png]]

---

![[Pasted image 20230830115146.png]]

![[Pasted image 20230830115354.png]]

![[Pasted image 20230830115535.png]]

![[Pasted image 20230830115726.png]]

 
