
## Introduction

---
#### Internet Protocols
IPv4: 2^32 addresses

4-8 bit components (32 bits)

**192 . 168 . 123.  254**

IPv6: 2^128 addresses 

8-16 components (128 bits)

**3fae : 7a10 : 4545 : 9 : 291 : e8ff : fe21 : 37ca**

![[Screenshot 2023-01-31 at 4.21.45 PM.png]]

---

###### Transport Layer (TCP)

Ensures transmissions arrive in order and without error
It's going to keep trying until it times out.

---
###### Application Layer
There are many application layer protocols. Web developers should be aware of:

* ***HTTP**
* ***SSH**
* ***FTP**
* ***POP/IMAP/SMTP**
* ***DNS**

---
#### Domain Name System (DNS)

DNS can also be the middle-man or reseller.

![[Screenshot 2023-01-31 at 4.21.24 PM.png]]

![[Screenshot 2023-01-31 at 4.22.39 PM.png]]

---

#### Uniform Resource Locators (URL)

"?" means query 
![[Screenshot 2023-01-31 at 4.31.01 PM.png]]

The domain identifies the server from which we are requesting resources

URL is case insensitive.

An IP Address can be used for the domain

>Optional port attribute allows us to specify connections to port other than the defaults

---

Hypertext Transfer Protocol

Provides info about the network 

Web server: Computer that serves websites

---
address resolution: sends a request to dns server and looks for the ip address. 

4 layer network model: 

TCP/IP: Part of transport layer and it allows data to be set back and forth and uses handshake to ensure connection.

Ip address is responsible for the where. where is the request going?

TCP is for the what and how. what  am i transporting? what is the data? how am i doing this?

---

#### Quiz
###### Match the vocabulary's and descriptions

URL: identifies the server from which we are requesting resources. 

Http: protocol to describe how request and responses operate

what is a web server: Nothing more than a computer that responds to HTTP request using server software.

HTML: Hypertext Markup Language

what is circuit switching and packet switching: circuit sends things in one chunk, but packets splits the chunk and they end up together in the end.

difference between url and ip address: URL provides a way to access a particular web page on the world wide web. However, an IP address identifies a specific device connected to the Internet.
resolution of url and ip address.

difference between the internet and web: public networks of networks. web is a system of accessing the internet.

what is the browser: the program you use to view web pages. Similar to librarian. Finding the website you like and converting it from code and into something more user friendly. When you request a web page, the browser sends request to DNS. DNS connects you to server where webpage is stored. This server sends source code back to the browser. Source code is written in many languages 

what is the hard drive: storage.
what is a http request: request to receive info from server.

image: picture?

web server: can respond to http requests

what is an internet packet and things inside internet packet (think about post card). computer breaks down message into many pages and gives instructions how to read and solve any issues that may occur.

another question about tcp and ip: ??

know what a routing table is: A routing table contains the routes packets need to take to reach their destination. If a routing table does not contain a route for an IP address then the default gateway is used. The default is like if you don't know how to get somewhere, but you know somebody who does so you tell anybody that asks to see that person. (address book for networks)

know what a dns server is:
IP Address is like a phone number. DNS is the phone book. URL is the name of the person you want to call.

know what a cache is:
autocompletion of user website history and forms.

only 8 questions



![[L03-How-Web-Works.pdf]]