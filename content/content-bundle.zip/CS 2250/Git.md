## Introduction

---
git init
git status
git add .
git commit -m ""
git remote add origin
git push -u origin main 


