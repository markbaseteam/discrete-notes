## Introduction

---
git init
git status
git add .
git commit -m ""
git remote add origin
git push -u origin main 

![[Screenshot 2023-02-18 at 11.34.05 PM.png]]
