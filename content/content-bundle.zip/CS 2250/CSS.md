
## Introduction

---

**Inline:**
``` html
<p style="color:red"> Hello </p>
```
**Internal:**
```html
<head>
  <style>
	p { color:red; }
  </style>
</head>
```

**External:**
```html
<head>
  <link rel="stylesheet" href="style.css">
</head>
```

---

#### Referral Link:

[[html-css-reference.pdf]]