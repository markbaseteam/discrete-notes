## Introduction

---

# Information about the terminal and GIT

#### Terminal commands

**ls -l**: shows directory and information about the directory.

**ls -la**: shows directory and information about directory including hidden files.

**history**: shows all previous commands made in terminal.

**cat, head tail, page more**:  display contents of files

**rm**: removes files (and directories)

**cp**: copies files (and directories)

**mv**: moves (renames) files (and directories)

**cd**: changes directories

**mkdir**: make empty directories

**rmdir**: remove empty directory

**pwd**: display name of present working directory

**man history**: manual page for history

**cd**: change directory

**.**: current working directory.

**..**: parent directory.

**touch**: create file
	touch test {1...3} // files 1 through 3

**script**:  -a test.scr (//append and then file)

**tar**: tar up, tape archiver, zip type of deal, grab a whole bunch of files and put into a single file basically to move it around (scp=secure copy) tar

**-cf workspace.tar workspace** //- command line switch -c(create) file or archive f stands for filename

**output file to local**: scp jmdang@login.cpp.edu:jmdang_example.scr .



---

#### Special control keys

**CTRL c**: interrupt (stop program/command)
**CTRL d**: halt or EOF
**CTRL g**: bell
**CTRL h**: backspace
**CTRL l**: redraw screen
**CTRL u**: kill (erase) line
**CTRL w**: kill word
**CTRL z**: suspend
**CTRL s**: stop the screen from scrolling
**CTRL q**: continue scrolling

---

#### git commands

**git status**: This command lists all the files that have to be committed.

**git config**:
Usage: `git config –global user.name “[name]”`  

Usage: `git config –global user.email “[email address]”`  

This command sets the author name and email address respectively to be used with your commits.

**git init [repository name]**: This command is used to start a new repository.

**git clone [url]**: This command is used to obtain a repository from an existing URL.

**git add:** This command adds one or more to the staging area.

**git commit -m**: This command records or snapshots the file permanently in the version history.

**git rm [filename]**: This command deletes the file from your working directory and stages the deletion.

**git log**: This command is used to list the version history for the current branch.

**git remote**: Usage: `git remote add [variable name] [Remote Server Link]`  

This command is used to connect your local repository to the remote server.

**git push**: Usage: `git push [variable name] master`  

This command sends the committed changes of master branch to your remote repository.

**git pull**: Usage: `git pull [Repository Link]`  

This command fetches and merges changes on the remote server to your working directory.

**git branch**: This command lists all the local branches in the current repository.

**git checkout**: Usage: `git checkout [branch name]`
This command is used to switch from one branch to another.

**git merge**: Usage: `git merge [branch name]`  

This command merges the specified branch’s history into the current branch.

---

#### Terminal Emulation

**Terminal Emulation**: Shell is the program that gives you the interface of the operating system and gives you features to do inside of it.

**echo $STERM**: identifies your login terminal type.
who am i: identifies your username and terminal ID.

**ctrl d**: issues an end of file input.
