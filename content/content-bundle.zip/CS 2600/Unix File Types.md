## Introduction

---

# Unix System Structure

**kernel**:
- Part of OS that sets abstraction between hardware and software.
- responsible for BIOS
- security

**hardware**:
* guts of computer

**GCC**: 
- toolset that compiles for C++, C
- First thing when you use GCC, the input to the compiler is its source code. It hits the preprocessor. Then it comes out as expanded source code. The compiler optimizes and spits out assembly code. Assembler takes out source code and converts it into machine code. Assembler outputs machine code. Its brought back into the linker. Output of linker is executable.
	-  1) Preprocessor 
	-  2) Compile optimizes
	-  3) Assembler
	- 4) Linker

**Word count**: 
* wc -l {filename}

**Byte - address**:
* byte addressable memory means every byte has an address

**64 - bit**:
- to address a single byte, we would need 64 bits to access a single memory. In a 32 - bit, the largest amount of bytes we can have is 2^32 bytes. (4 GB)
- 2 hexadecimal digits for 1 byte.

**inode:** 
- data structure that keeps tracks and stores information in files

**Ordinary Files:**
- Used to store information such as text written or image. 

**Directories:**
- May contain ordinary files, special files, or other directories

**Special Files:**
- Used to represent a real physical device such as a printer, hard drive, terminal, used for Input/Output (I/O) operations.

**Pipes:**
- UNIX allows you to link commands together using a pipe. (IPC) Interprocess communication
- acts as a temporary file which only exists to hold data from one command until it is read by another.

If its an absolute path, it begins with a forward slash.

3 privileges in this order are:
- r w x

**Bitmaps:**

---

touch file
ll
mkdir filedir
ll

(chmod 000 fileDir)







