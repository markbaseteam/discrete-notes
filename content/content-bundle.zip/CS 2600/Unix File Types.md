## Introduction

---

# Unix System Structure

**kernel**:
- Part of OS that sets abstraction between hardware and software.
- responsible for BIOS
- security

**hardware**:
* guts of computer

**GCC**: 
- toolset that compiles for C++, C
- First thing when you use GCC, the input to the compiler is its source code. It hits the preprocessor. Then it comes out as expanded source code. The compiler optimizes and spits out assembly code. Assembler takes out source code and converts it into machine code. Assembler outputs machine code. Its brought back into the linker. Output of linker is executable.
	-  1) Preprocessor 
	-  2) Compile optimizes
	-  3) Assembler
	- 4) Linker

**Word count**: 
* wc -l {filename}

**Byte - address**:
* byte addressable memory means every byte has an address

**64 - bit**:
- to address a single byte, we would need 64 bits to access a single memory. In a 32 - bit, the largest amount of bytes we can have is 2^32 bytes. (4 GB)
- 2 hexadecimal digits for 1 byte.

---
# Two Primary Kernel Subsystems 

**File Systems:**
- deals with all input and output
  - includes files and terminals 
  - integration of storage devices
  
**Process management:**
- Deals with program and program integration
  - How processes share CPU, memory, and signals
  - Scheduling
  - Inter process communication (IPC)
  - Memory management

---

**inode:** 
- data structure that keeps tracks and stores information in files

---
# Ordinary Files vs Directories 

**Ordinary Files:**
- Used to store information such as text written or image. 
- Type of file you usually work with.
- Always located under/within a directory file

**Directories:**
- May contain ordinary files, special files, or other directories
- Used to organize groups of files
- All files are descendants of the root directory, (named / ) located at the top of the tree.

[referral](http://underpop.online.fr/l/linux/en/centos/directory-files-and-ordinary-files.htm)

---

# Unix File Types (2 of 2)

**Special Files:**
- Used to represent a real physical device such as a printer, hard drive or terminal, used for Input/Output (I/O) operations.
- Unix considers anything attached to the system to be a file - including terminal
	- By default, a command treats your terminal as the standard input file (stdin) from which to read its input
	- Your terminal is also treated as the standard output file (stdout) to which a commands output is sent
- Two types of I/O: character and block
	- Usually only found under directories named /dev
	
**Pipes:**
- UNIX allows you to link commands together using a pipe. (IPC) Interprocess communication
- acts as a temporary file which only exists to hold data from one command until it is read by another.

---
#### Tips

If its an absolute path, it begins with a forward slash.

---

# Finding File types using file

**file "filename"**: identifies filename

Unix permits file name to use most characters, but avoid spaces, tabs and characters that have a special meaning to the shell such as: **& : ( ) | ? ' " [ ] { } <> $ - ! /**

* Upper and lower case are not the same! Stick to lowercase with the occasional use of upper.
* Length: 256 characters

---

# File Names

**Hidden Files**: have names that begin with a dot (.)
* Ex: .login, .cshrc, .mailrc, 
* Mostly resource configuration files begin with a .

**Uniqueness**: 
- as children in a family, no two files with the same parent directory can have the same name. Files located in separate directories can have same name.

**Reserved Filenames**:
- / the root directory (slash)
- . current directory (period)
- .. parent directory (double period)
- ~ home directory (tilde)

---

# Pathnames 

- Specify where a file is located in the hierarchically organized file system.
- Must know how to use pathnames to navigate UNIX file system.
- **Absolute Pathname**: tells user how to reach a file beginning from the root; always begins with / (slash).
	- Ex: /usr/local/doc/training/sample.f
- **Relative Pathname**: tells user how to reach a file from directory you are currently in (current or working directory); never begins with / (slash).
	- Ex: training/sample.f ../bin ~/projects/reports.001
- For example, if your directory is /usr/home/raheja and you wanted to change to the directory /usr/home/daatanasio, you could use either of these commands.
	- cd ../daatanasio - *relative pathname*
	- cd /usr/home/daatanasio - *absolute pathname*

---

# Pathname Example

![[Screenshot 2023-02-19 at 5.15.50 PM.png]]

---

# Definition: Current Working Directory

![[Screenshot 2023-02-19 at 5.16.17 PM.png]]

---

# Definition: Relative Pathname

![[Screenshot 2023-02-19 at 5.18.10 PM.png]]

---

# Hierarchal File System

![[Screenshot 2023-02-19 at 5.19.05 PM.png]]

---

# Unix Hierarchical File Structure

* All the files in Unix File System are organized in a multi-leveled hierarchy called a directory tree
- Family tree is an example of hierarchy structure that represents how the UNIX file system is organized. UNIX file system might be envisioned as an inverted tree or a root system of plant
- Top of the file system is a single directory called "root" which is represented by a / (slash). All other files are descendants of root.

---

# General FHS for Linux

**/ - Root**:
- Every single file and directory start from the root directory.
- Only root user has write privilege under this directory.
- Please note that /root is root user's home directory which is not the same as /.

**/bin - User Binaries**:
- Contains binary executables
- Common linux commands you need to use in single-user modes are located under this directory.
- Commands used by all the users of the system are located here.
- Ex: ps, ls, ping, grep, cp

**/sbin - System Binaries**: 
- Just like /bin, /sbin also contains binary executables
- But linux commands under this directory are used typically by system administrator, for system maintenance purposes.
- Ex: iptables, reboot, fdisk, ifconfig, swapon

**/etc - Configuration Files**:
- Contains configuration files required by all programs
- This also contains startups and shutdown shell scripts used to start/stop individual programs
- Ex: /etc/resolv.conf, /etc/logrotate.conf

**/dev - Device Files**:
- Contains device files
- includes terminal devices, usb, or any device attached into the system.
- Ex: /dev/tty1, /dev/usbmon0

**/proc - Process Information**:
- Contains information about system process
- Is a pseudo filesystem containing information about running process. For example: /proc/{pid} directory contains information about the process with that particular pid.
- virtual filesystem with text information about system resources. For example: /proc/uptime

**/var - Variable Files**:
- var stands for variable files
- Content of files that are expected to grow can be found under this directory.
- Includes: system log files (/var/log); packages and database files (/var/lib); emails (/var/mail): print queues (/var/spool); lock files (/var/lock); temp files needed across reboots (/var/tmp);

**/tmp - Temporary Files**:
- Directory that contains temporary files created by system and users
- Files under this directory are deleted when system is rebooted

**/usr - User Programs**:
- contains binaries, libraries, documentation, and source code for second level programs.
- /usr/bin contains binary files for user programs. If you can't find  a user binary under /bin, look under /usr/bin. For example: at, awk, cc, less, scp
- /usr/sbin contains binary files for system administrator. If you can't find a system binary under /sbin, look under /usr/sbin. For example: atd, cron, sshd, useradd, userdel,
- /usr/lib contains libraries for /usr/bin and /usr/sbin
- /usr/local contains user programs that you install from the source. For example, when you install apache from the source, it goes under /usr/local/apache2

**/home - Home Directories**:
- Home directories for all users to store their personal files
- For example: /home/john, /home/nikita

**/boot - Boot Loader Files**:
- Contains boot loader related files
- Kernel initrd, vmlinux, grub files are located under /boot
- For example: initrd.img-2.6.32-24-generic, vmlinuz-2.6.32-24-generic 

**/lib - System Libraries**:
- Contains library files that supports the binaries located under /bin and /sbin
- Library filenames are either Id* or lib*.so.*
- Example: Id-2.11.1so, libncurses.so.5.7

**opt - Optional add-on Applications**:
- opt stands for optional
- Contains add-on applications from individual vendors
- add-on applications should be installed under either /opt or /opt/sub-directory

**/mnt - Mount Directory**:
- Temporary mount directory where sysadmins can mount filesystems

**/media - Removable Media Devices**:
- Temporary mount directory for removable devices
- Example: /media/cdrom for CD-ROM; /media/floppy for floppy drives; /media/cdrecorder for CD writer

**/srv - Service Data**:
- srv stands for service
- Contains server specific services related data
- Example: /srv/cvs contains CVS related data

---

# Typical Filesystem Directory Contents

![[Screenshot 2023-02-19 at 6.16.53 PM.png]]

---

# Fundamentals of Security

- Unix system have one or more users, identified with a number and name.
	- Unix is a multi-user system
- A set of users can form a group. User can be member of multiple groups
	- A special user(id 0, named root) has complete control.
	- Every user has a username, numeric uid(user identification), a default group association, optional associations with other groups are possible.
- id: view your uid and default group and which groups you belong to.

---

# File/Directory Access Permissions

- Every file and directory in your account is protected from others
- Every file has
	- A single owner
	- An association with a single group
	- A set of access permissions associated with it
- For a File, permission control what can be done to file contents
- For a Directory, permission control whether a file in that directory can be listed, searched, renamed, or removed.

---

# How are Users and Groups used?

- Used to determine if file or process operations can be performed:
	- Can a given file be read? written to?
	- Can this program be run?
	- Can I use this piece of hardware?
	- Can I stop a particular process thats running?
- UNIX provides a way to protect files based on users and groups
- Three **types** of permissions:
	- read, process may read contents of file
	- write, process may write contents of file
	- execute, process may execute contents of file
- Three **sets** of permissions:
	- permissions for owners
	- permissions for group (1 group per file)
	- permissions for other

---

# File Access Permissions

- Every user has responsibility for controlling access to their files and directories.
	- Can be made accessible to other users by changing its access permissions only by the owner of file.
- Permissions for a file or directory may be any or all of the following: 
	- **r** - read
	- **w** - write
	- **x** - execute = running a program
- Each permission (rwx) can be controlled at three levels
	- **u** - user = yourself
	- **g** - group = can be people in the same project
	- **o** - other = everyone on the system

---

# Directory Access Permissions

- Same types and sets of permissions as for files
	- **read**: process may read the directory contents (i.e., list files)
	- **write**: process may add / remove files in the directory
	- **execute**: process may open files in directories or subdirectories 

![[Screenshot 2023-02-19 at 6.29.58 PM.png]]

---

# Viewing File Permissions

![[Screenshot 2023-02-19 at 6.30.54 PM.png]]

---

# Access Permissions

![[Screenshot 2023-02-19 at 6.32.33 PM.png]]

---

# Utilities for Manipulating File Attributes

**chmod**: 
- change file permissions

**chown**: 
- change file owner 

**chgrp**:
- change file group

**umask**:
- user file creation mode mask
- only owner or super-user can change file attributes
- upon creation, default permission given to file modified by process **umask** value

![[Screenshot 2023-02-19 at 6.36.50 PM.png]]

---

# Permission Settings for Octal Mode

- Permission settings use octal numbers
	- **r** = 100 = 4
	- **w** = 010 = 2
	- **x** = 001 = 1
	- **None** = 000 = 0
- These numbers are additive 
	- **rwx** = 7(4 + 2 + 1) = 111
	- **rw** = 6(4 + 2) = 110
	- **rx** = 5(4 + 1) = 101

---

# Numerical Access Permissions

![[Screenshot 2023-02-19 at 6.39.40 PM.png]]

---

# Chmod command

![[Screenshot 2023-02-19 at 6.40.20 PM.png]]

---

# Permission Settings: Examples

![[Screenshot 2023-02-19 at 6.40.59 PM.png]]

---

# Changing Permissions

**chmod**:
- command is used to directly modify permissions. can only be used by the owner of the file/dir (or the administrator root)

![[Screenshot 2023-02-19 at 6.43.05 PM.png]]

---

# Chmod Examples

![[Screenshot 2023-02-19 at 6.43.34 PM.png]]

---

# Advanced Permissions Flags

- The special permissions flag can be marked with any of the following:
	- _ -  no special permissions 
	- d - directory
	- I - The file or directory is a symbolic link
	- s - This indicated the setuid/setgid permissions. This is not displayed in the special permissions part of the permissions display, but is represented as a *s* in the execute portion of the owner or group permissions
	- t - This indicates the sticky bit permissions. This is not set displayed in the special permission part of the permissions display, but is represented as a *t* in the executable portion of all user permissions

---

# What is SUID and SGID?

![[Screenshot 2023-02-19 at 6.52.44 PM.png]]

![[Screenshot 2023-02-19 at 6.52.56 PM.png]]

https://www.computerhope.com/unix/uchmod.htm







