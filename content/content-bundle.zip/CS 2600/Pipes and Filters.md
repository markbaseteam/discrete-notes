## Introduction

---

**IPC**: 
- Inter Process Communication

---

# What are Pipes?

- General idea or Motivation for pipes in UNIX
	- The input of one program is the output of the other, and vice versa
	- Both programs run at the same time
- Often, only one end of the pipe is used
- Could this be done with files?


---

# Bad File Approach: Motivation for Pipes

- Run first program, save output into file
- Run second program, using file as input

![[Screenshot 2023-02-26 at 4.24.36 AM.png]]

- Unnecessary use of the disk
	- Slower
	- Can take up lots of space
	- Hard drive is the slowest piece of machine.
- Makes no use of multi-tasking

---

# Design Philosophy of Pipes

- End goal: Achieve complex task by combining individual utilities 
- Pipes are often chained together (used for redirection)
- Pipes follow the FIFO (first in, first out) mechanism
- What if a process tries to read data, but nothing is available?
	- UNIX puts the reader to sleep until data available
- What if a process can't keep reading from the process thats writing?
	- UNIX keeps a buffer of unread data
		- referred to as pipe size.
		- ![[Screenshot 2023-02-26 at 4.28.16 AM.png]]
	- If the pipe fills up, UNIX puts the writer to sleep until the reader fills up space (by doing a read)
- Multiple readers and writers possible with pipes

---

# Examples of Pipes

![[Screenshot 2023-02-26 at 4.28.34 AM.png]]

---

# Filters

- Filters are a class of UNIX utilities that read from standard input, transform the file, and write to standard out
- Using filters can be thought of as *data-oriented programming*
- Each step of the computation transform data stream
- Text processing commands are often implemented as filters
- Users can use file redirection and 'pipes' to setup 'stdin' and 'stdout' as per their need
- Pipes are used to direct the 'stdout' stream of one command to the 'stdin' stream of the next command
- Filters **do not** modify the original file but output the modified data from the file onto the standard output

---

# Popular UNIX Filters

• **cat**: Read lines from stdin (and more files), and concatenate them to stdout.  
• **more/less**: Read lines from stdin, and provide a paginated view to stdout.  
• **head**: Read the first few lines from stdin (and more files) and print them to stdout.  
• **tail**: Read the last few lines from stdin (and more files) and print them to stdout.  
• **tee**: Copy stdin to stdout and one or more files  
• **cut**: Cut specified byte, character or field from each line of stdin and print to stdout.  
• **paste**: Read lines from stdin (and more files), and paste them together line-by-line to stdout. 
• **wc**: Read from stdin, and print the number of newlines, words, and bytes to stdout.  
• **tr**: Translate or delete characters read from stdin and print to stdout.  
• **sort**: Sort the lines in stdin, and print the result to stdout.  
• **uniq**: Read from stdin and print unique (that are different from the adjacent line) to stdout.  
• **grep**: Find lines in stdin that match a pattern and print them to stdout.  
• **sed**: Streamline Editor used to edit text in non interactive mode.  
• **awk**: Powerful editing tool for files with programming features

---

# cat command

- The cat command copies its input to output unchanged (identity filter). When supplied a list of file names, it con**cat**enates them onto stdout.
- Some options:
	- -n: **n**umber output lines (starting from 1)
	- -v: display control-characters in **v**isible form (e.g ^M)
tail and head uses -n 

![[Screenshot 2023-02-26 at 4.34.39 AM.png]]

---

# more command

- more command same as cat but pages through the file
- $ more +4 foo
	- Displays the file content page by page starting at line 4
- press h for help after you run the more command to see options

white space separates the arguments

---

# tee 

![[Pasted image 20230301182202.png]]

**tee command** reads the standard input and writes it to both the standard output and one or more files. The command is named after the T-splitter used in plumbing. It basically breaks the output of a program so that it can be both displayed and saved in a file. It does both the tasks simultaneously, copies the result into the specified files or variables and also display the result.

---

