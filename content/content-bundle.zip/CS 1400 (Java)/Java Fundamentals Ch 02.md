## Introduction

###### Printing a statement on Java

```java
System.out.println();
System.out.print();
```

---
#### toString() function

We can use the toString() function on total.

```java
int total;
System.out.println("the total is " + total.toString());
```

---
###### Input

```java import.java.util.Scanner;*
int n;
Scanner keyboard = new Scanner(System.in);
n = keyboard.nextInt();
```
The object here is **Scanner**

**keyboard.~**
* integers ~ nextInt();
* strings ~ nextLine();
* double ~ nextDouble();
---
The library below is imported by default in the JDK.

`` import java.lang.* ``

---
#### Java escape sequences

**```\n```   newline:** Advances the cursor to the next line for subsequent printing

 ```\t```  **tab:** Causes the cursor to skip over to the next tab stop

```\t``` **backspace:** Causes the cursor to back up, or move left, one position

 **```\r``` Carriage return:**   Causes the cursor to go to the beginning of the current line not the next line
 
**```\\```  backslash: ** Causes a backslash to be printed

 **```\'```  single quote:** Causes a single quotation mark to be printed
 
**```\"``` double quote:** Causes a double quotation mark to be printed

---
#### Variables and Literals

Variable: Named storage location in the computer's memory.

Variable declaration: `int value;`

Assignment statement: `value = 5;`


Literal: Value that is written into the code of a program

String literal:  `"The value is "`

*A string literal value cannot span lines in a Java source code file.
The String concatenation operator can be used to fix this problem.*

---
#### Identifiers

Identifiers:  Programmer-defined names for 
- classes
- variables
- methods

###### Rules 
- letters a-z or A-Z
- the digits 0-9
- underscores __
- the dollar sign $
- cannot include spaces
- first character cannot be digit
- case sensitive
- Identifiers may not be any of Java reserved keywords.

---
#### Primitive Data Types

* Primitive data types are built into the Java language and are not derived from classes.

**<u>There are 8 Java primitive data types.</u>**
- byte ~ 1 byte
- short ~ 2 bytes
- int ~ 4 bytes
- long ~ 8 bytes
- float ~ 4 bytes
- double ~ 8 bytes
- char ~ 2 bytes
- bool ~ 1/8 bytes

---

#### Unicode

* Internally, characters are stored as numbers.

* Character data in Java is stored as Unicode characters.

* Unicode character set consist of 65536 ($2^{16}$) individual characters.

* Each character takes up 2 bytes in memory

* The first 256 characters in the Unicode character set are compatible with the ASCII* character set

* American Standard Code for Information Interchange

* Characters are stored in memory as binary numbers.

---
#### Creating Constants with `final` 

* Constants are declared using the keyword `final`.
* Name should be all upper case and words should be separarated by the underscore character.

`final double CAL_SALES_TAX = 0.725;`

---
#### The String Class

* Java has no primitive data types that holds a series of characters.
The String class is used for this purpose.

* Class names should always begin with an upper case character.

``String city = "Anaheim";``

---
#### Primitive vs Reference Variables

- Primitive variables contain the value that they have been assigned
 `number = 25;` 
- The value 25 will be stored in memory location associated with the variable number.

- Objects are not stored in variables, but are referenced by variables.
 `cityName = [Address to the object]  -----> ["Anaheim"]`

* A variable can be created using the *new* keyword.
`String value = new String("Hello");`



