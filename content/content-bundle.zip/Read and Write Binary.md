## Introduction

Quick notes on how to read and write Binary.

----

Binary can be translated with 2 to the power of n. (2^n).

n starts at 0 and is incremented by 1 as the number grows.

> 2^(n), 2^(n+1), 2^(n+2), 2^(n+3), etc..

###### Example:
|  1    |  1    | 0     |   1   |
|:-----|:-----|:-----|:-----|
|   2^3   |   2^2   |  2^1    |   2^0   |
|    8  |    4  |   2   |  1    |

Now, we ignore the numbers that has 0 above and add the numbers that has 1 above.

8 + 4 + 1 = 13.

1101 = 13.

We have now learned binary.

---

#### The Remainder method 

The remainder method can be a nice quicker way to determine binary to digit.

The remainder method works as shown below:

![[Screenshot 2023-01-31 at 1.05.13 AM.png]]

---

# Octal to Binary

Ex: 643

1. Split number into separate digits. 6, 4, 3
2. Find binary values of 6,4, 3.
3. Combine values together.

Answer: 110 100 011
