
## Introduction

---

**Host**: any device which sends or receives traffic
- Clients and Servers

**IP Address**: Identity of each host

**Network**: is what transports traffic between hosts
- Logical grouping of hosts which require similar connectivity.
- Sub-Networks / Subnets

---
#### Definition of Network
 * Grouping of hosts which require similar connectivity.
* A network is created anytime you connect two computers with a wire. 
* Data crossing the wire decays as it travels.
* Hosts on network share the same IP address space.

---

**Repeater**: device whose sole purpose is to regenerate signals. The signal will hit the middle, regenerate and reach greater distances to the end.

![[Pasted image 20230923202930.png]]

---

Connecting hosts directly to each other doesn't scale. As more hosts are created, it becomes very inconvenient. 
![[Pasted image 20230923203058.png]]

**Solution**: We can create a device in the center of the network that can connect all of the hosts together. These devices will handle tunneling communication between all the hosts. 

![[Pasted image 20230923203209.png]]

Examples: Hub, Bridge, Switch

---

**Hub**: multi-port repeaters. They do the same thing as repeaters but across multiple ports.

Example: If the left host sends a packet to the hub, it will duplicate the packet and send it out to all the other ports.

![[Pasted image 20230923203515.png]]

![[Pasted image 20230923203523.png]]

Problem: Everybody receives everyone else's data.

---

**Bridges**: sit between Hub-connected hosts. 

![[Pasted image 20230923203731.png]]

Only have two ports. One facing the direction of one of hub connected devices and the other vice versa.

Bridges learn which hosts are on which side of the bridge. This allows the bridge to contain communication to the side that is necessary.

![[Pasted image 20230923203858.png]]

Example: If the left host and left bottom host need to speak to each other. When they send data through that hub, the bridge also gets a copy of the packet, but the bridge knows the other host is on the left side and therefore, it won't bring it to the other side.

![[Pasted image 20230923204116.png]]

 ![[Pasted image 20230923204125.png]]

Other examples:

![[Pasted image 20230923204220.png]]

![[Pasted image 20230923204233.png]]

---

**Switch**: They are like hubs in the sense that many devices can connect to the switch.

They are like bridges in the sense that it can learn which hosts are on each port.

Main difference is that they are doing it on a per port basis.

![[Pasted image 20230923204729.png]]

Example: If these two hosts want to speak to each other, the switch will know the only port that needs to receive this traffic are the two that are connected to the green hosts.

![[Pasted image 20230923204805.png]]

![[Pasted image 20230923204849.png]]

![[Pasted image 20230923204857.png]]

Another example: 

![[Work-Principl-of-Switch.gif]]

A switch is a device that facilitates connection within a network.

All of these devices belong to the same [[Hub, Bridge, Switch, Router - Network Devices#Definition of Network|Network]]

Example:

![[Pasted image 20230923205611.png]]

192.168.1 is the network IP. Each unique host will have a number that comes after the IP. Such as 192.168.1.33. 

This can represent the devices on your home WIFI or a School network. Schools might have a network for each classroom.

![[Pasted image 20230923205827.png]]

The reason why you might want to separate the two is because they might have different connectivity requirements.

Example: Classroom 2 might be a Biology classroom and all they need is a simple network connectivity.

However, Classroom 3 might be a Computer Science classroom and they not only need a simple network connectivity, they might also need access to cloud resources to do their studies.

---

What happens when Host .33 wants to speak to host .44? Since a switch can only communicate within a network, you would need another device.
That device would be a **router**.

![[Pasted image 20230923210213.png]]

**Router**: Purpose is to facilitate communication between networks.

Eventually, you will need the router to connect you to the ultimate network also known as the Internet.

![[Pasted image 20230923210335.png]]

Routers provide traffic control points between networks. 

Lets say if .11 wants to go to .44. During its path when it reaches the router in the middle, the router can provide a traffic control point such as security, filtering, or even redirecting it elsewhere.

Routers learn which networks they are attached to. It knows that on the left interface, it is connected the 172.16.20.x network and vice versa for the right interface. 

This knowledge is also known as routes. All these routes are stored in a **Routing Table**.

**Routing Table**: all networks a Router knows about.

![[Pasted image 20230923210602.png]]

Routers have an IP address in every network they are attached to.

![[Pasted image 20230923210836.png]]

For example, the left side's identity would be 172.16.20.1. 

This IP address is gonna serve as a Gateway.
**Gateway**: host's way out of their local network.

Example: .33 wants to speak to another host on a different network. It knows it has to go through a router which holds the default gateway.
![[Pasted image 20230923211040.png]]

Routers create the hierarchy in networks and the entire internet. 

Example: Each of the networks in New York are connected to different routers and each of those routers are connected to another router.

If a host on the sales team wants to speak to the host on the marketing team, it's going to use it's gateway (closest router IP address) and it's going to send its packet to the next router and the next router and finally to the host on the marketing team.

![[Pasted image 20230923211306.png]]

![[Pasted image 20230923211450.png]]

The Tokyo office will have a similar setup and both of the outer routers are most likely going to connect to the internet. The internet holds a bunch of different routers itself.

![[Pasted image 20230923211555.png]]

---

* Routers facilitate communication **between networks**.

* Switches facilitate communication **within** a network.

* ***Routing*** is the process of moving data between networks.

* A Router is a device whose primary purpose is routing.

* Switching is the process of moving data within networks.

* A Switch is a device who's primary purpose is Switching.