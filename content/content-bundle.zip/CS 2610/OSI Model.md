
### Introduction

---

**Purpose of Networking**: Allow two hosts to share data with one another automatically.

Hosts must follow a set of rules.
- Example: English and Spanish language has rules.

The rules of Networking are divided into seven layers.

![[Pasted image 20230923212754.png]]

The entire networking system be compared to an analogy of the Human Body. Each layer serves a specific purpose within the OSI model. If all layers are functioning, hosts can share data.

---

#### Layer 1 - Physical

* Computer data exist in the form of Bits (1's and 0's)
* Something has to transport those bits between hosts.

Anything that is designed to move the 1's and 0's from computer 1 to computer 2 is a Layer 1 technology.

![[Pasted image 20230923213105.png]]

Examples: Cables are Layer 1 technology. All takes something from one end and outputs it to the other end.

![[Pasted image 20230923213533.png]]

WIFI can also be considered a Layer 1 technology as it's purpose is to carry bits from one computer to the next.

Repeaters are also considered as Layer 1 technology as it amplifies signals from one end to the other end. 

Repeaters are nothing more than something that allows you to extend a wire. This also means that multi-port repeaters such as Hubs can be also considered.

---

#### Layer 2 - Data Link

* Interacts with the Wire (i.e., Physical layer)
* It will put bits on the wire and retrieve bits from the wire.
* Whatever this wire actually connects to on this PC is considered a Layer 2 item.

NIC - Network Interface Cards & Wi-Fi Access Cards are examples of Layer 2 items.

![[Pasted image 20230923213702.png]]

Overall Goal of Layer 2 is Hop to Hop delivery.
Layer 2 exists to take 1's and 0's from NIC 1 to NIC 2

![[Pasted image 20230923213858.png]]

To accomplish the goal, we need to use an Addressing Scheme also known as MAC addresses.

**MAC addresses**: 48 bits, represented as 12 hex digits
* 94-65-9C-3B-8A-E5
* 94:65:9C:3B:8A:E5

Same MAC addresses above, just differently displayed between OS.

Every single NIC has a unique MAC address.

PC 1 might have an address of a1a1.
PC 2 might have an address of e8e8.
*(4 digits only shown to preserve space)*

The addresses allow data to go from one NIC to the next.

**Switches** are also Layer 2 items.

If these two hosts are connected via the switch, the switch is going to help traffic move along to help accomplish this hop.

![[Pasted image 20230923214344.png]]

Example: If these two hosts want to speak with each other, the switch can internally connect them to each other such that data can traverse from NIC to NIC.

![[Pasted image 20230923214453.png]]

Often communication between hosts require multiple hops. 

![[Pasted image 20230923214625.png]]

Routers can deliver data from the first MAC address to the next and so on. From one NIC to the next.

![[Pasted image 20230923214711.png]]

If layer 2 is taking care of the hops, what is taking care of ensuring that data goes from this endpoint to the next?

![[Pasted image 20230923214812.png]]

---

#### Layer 3 - Network - End to End

Network is also known as End to End delivery.

Going to use it's own Addressing Scheme known as IP addresses
- 32 bits, represented as 4 octets, each 0-255.

Every host is going to be identified by it's own IP address. 

These IP addresses are going to allow data to go from here to here.

![[Pasted image 20230923215044.png]]

* Routers are known to exist in the Layer 3 category.
* Hosts are known to exist in the Layer 3 category.
* Anything with an IP address is in Layer 3.

If we have IP addresses, why do we need MAC address? and vice versa.

Reason is because each of those Addressing Schemes serves two different purposes. 

IP Addresses - End to End delivery
MAC Addresses - Hop to Hop delivery

Example: The left host has some data it needs to send to the right host in the end. That data is just a bunch of bits. Layer 2 of 3 don't know what it contains. 

![[Pasted image 20230923215358.png]]

Since left computer knows that data needs to get to the endpoint, its going to add some layer 3 information to that data. That layer 3 information includes the source IP address and the destination IP addresses.

Now the computer knows that the first step would be getting the data to the first router.

![[Pasted image 20230923215544.png]]

 Which would prompt the computer to add layer 2 information to that data which includes a source MAC address of the computer's NIC and a destination MAC address of the first router's NIC.

![[Pasted image 20230923215659.png]]

That will get the info to the first router.

![[Pasted image 20230923215753.png]]

Once it gets there, we can remove layer 2 information. It's only purpose was to get from host a to host b. Now with the layer 3 info, the current router now knows that it needs to get to the next router.

It's going to move by adding another layer 2 header of source MAC address and destination MAC address.

![[Pasted image 20230923215907.png]]

After traversing, we can get rid of layer 2's information once again. 

We will keep repeating the steps until it reaches the final host. Now both layer 2 and 3 headers can be removed because the purpose for the IP address was to bring the data from the starting position to ending.

![[Pasted image 20230923220132.png]]

Finally the data can be reprocessed by the receiving host.

This is why we need both IP addresses and MAC addresses as they serve different functions.

---

Both MAC and IP addresses are independent functions, but there is a protocol that can tie them together.

**ARP**: Address Resolution Protocol
* Links a L3 address to a L2 address

![[Pasted image 20230923220323.png]]

---

#### Layer 4 - Transport - Service to Service

Example: We have a computer and it has a MAC addresses and an IP address. We are using the web browser and at the same time, we are also playing Minecraft.

Each of those programs is meant to send and receive data on the wire. All that data will be destined to the Layer 3 IP address to accomplish End to End Delivery and Layer 2 to accomplish Hop to Hop Delivery.

How do we ensure that the right program receives the right packet?


![[Pasted image 20230924174826.png]]

**Layer 4**: Distinguish data streams

It is responsible for taking all that incoming data and ensures that the right program receives the right data.

![[Pasted image 20230924175135.png]]

Layer 4 has it's own Addressing Scheme which are **Ports**.

Two sets of ports:
- 0-65535 - TCP - favors reliability 
- 0-65535 - UDP - favors efficiency 

Every single program that is expected to receive data on the wire is going to be associated with a particular port number.

When data arrives on the wire, it is going to include a Layer 4 header, in addition with Layer 3 and 2 header.

That layer 4 header will indicate which program should receive the data.

![[Pasted image 20230924175730.png]]

Example: Below is a client and 3 servers.

Review: A server is just a computer which is running software which knows how to respond to specific request.

Each of these software is assigned a pre-defined well known port number which correlate to the underlying network application.

![[Pasted image 20230924180918.png]]

If bank.com is listening for secure web request using HTTPS which is assigned TCP / 443.

The server site.com is responding to general web request using HTTP which is listening on TCP / 80

The chat server is running on IRC (Internet Relay Chat) which runs on UDP / 6667.

When the client makes a request on these servers, its not only making a request to the IP addresses, but it also makes a request to the specific Port such as TCP / 443.

Then, for each request made by the client, the client is going to select a random port number as a source port for the connection.

9999 is the  source port the client randomly selected for the connection.

The destination is the IP address going TCP port 80 which is the HTTP application.

**Reminder**:
Source and Destination IP Addresses exist in Layer 3.
Source and Destination Port exist in Layer 4.

![[Pasted image 20230924181504.png]]

The source ports are very important as it is the port the client will listen to for the response to the original request.

Example: If the site.com server responds to the web request, that packet should look like this below.

![[Pasted image 20230924181837.png]]

Destination port is usually governed by the application in use, but source port is randomly selected by client.

![[Pasted image 20230924182118.png]]

Whatever comes back from the port 8888 will be given to the web browser.

These ports ensure that the right applications will get the right data.

Example: Consider you are browsing the internet. You will often have multiple tabs opened. The reason each of those active tabs don't accidently display data from another tab each time you open up a tab is because your web browser generates a new random source port.

![[Pasted image 20230924182502.png]]

---

#### Layer 5, 6, 7 - Session, Presentation, Application

* Distinction between these layers is somewhat vague.
* These layers are considered to be a single universal application.

Other Networking Models combine these into one layer.

![[Pasted image 20230924182920.png]]

---
#### The process between two hosts communicating

![[Pasted image 20230924185052.png]]

The left host has an application that is going to generate data meant to be sent to the other side.

What that host is going to go through is known as the Encapsulation Process.

![[Pasted image 20230924185150.png]]

That data is going to be sent into Layer 4, where it is going to add a header to the data to fit the service to service delivery goal.

In this case, it is a TCP header which includes the source and destination port.

The construct of a layer 4 header + data is known as a segment.

![[Pasted image 20230924185257.png]]

That segment is going to be passed down the OSI stack to the next layer, which is layer 3. The network layer is going to add another header to this data.

This layer is going to fit the end to end delivery goal by adding IP header to it. This means it will have a source IP address and a destination IP address.

The construct of a layer 3 header + data is known as a packet.

Layer 3 does not know what is in the data besides a bunch of bits. It's job is to transport it to layer 2.

![[Pasted image 20230924185516.png]]

Layer 2 will now add another header to the data to accomplish hop to hop delivery. It will include a source MAC address and a destination MAC address.

The construct of a layer 2 header + data is known as a frame.

![[Pasted image 20230924185755.png]]

That frame later gets converted into 1's and 0's and finally gets put onto the wire. 

On the other side, the receiving host is going to do the opposite. It will so De-Encapsulation.

De-Encapsulation is taking 1's and 0's off the wire and converting it back into their frame.

![[Pasted image 20230924185904.png]]

Layer 2 will take a look at it's header to see if its addressed to the right host's NIC. If it is, it will discard the layer and pass it up the stack.

![[Pasted image 20230924190017.png]]

Then, layer 3 will look at the IP header and confirm if its addressed to the right host's address. If it is, it will discard the layer and pass it up the stack.

![[Pasted image 20230924190111.png]]

Layer 4 will take a look at the layer 4 header to identify the port that this data is destined to. It will deliver the data to the appropriate application.

The application can then process the data. 

![[Pasted image 20230924190141.png]]

---

#### OSI Model

* Layer 2 devices only look into the datagram up to Layer 2 header (Switches)

* Layer 3 devices only look into the datagram up to Layer 3 header (Routers)

* Network Protocols operate at specific layers.
	* TCP/UDP Ports only operate at Transport
	* IP Addresses only operate at Network
* Neither of these are strict rules - **exceptions exists**

![[Pasted image 20230924190546.png]]



