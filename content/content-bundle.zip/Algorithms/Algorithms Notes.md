## Introduction
My notes for Design and Analysis of Algorithms 

---

# Difference between Algorithms and Programs

**Algorithm:** 
* is written at design.
- person who wrote this should have domain knowledge (understanding).
- any language can make algorithm, even english.
- not dependent on hardware or OS.
- Analyze an algorithm to see how efficient.

**Program:** 
* written in implementation time.
* programmers write program.
* programming language is used to make program.
*  dependent on hardware or OS.
* Testing of the program

---

# Priori Analysis and Posteriori Testing

**Priori Analysis:**
* Done in Algorithm
* Independent of Language
* Hardware Independent 
* Time and Space Function

**Posteriori Testing:**
- Done in Program
- Language dependent 
- Hardware dependent 
- watch time and bytes

---

# Characteristics of Algorithm

###### What are the properties of an Algorithm?

1. **Input:** can take 0 or more input.
2. **Output:** at least 1 or more output.
3. **Definiteness:** must give clear meaning / one meaning. Know the steps you are performing.
4. **Finiteness:** must terminate at some point. must have finite statements.
5. **Effectiveness:** shouldn't have unnecessary statements. 

---

# How to Write and Analyze Algorithm

There is no fixed syntax for writing algorithm.

Algorithm swap(a,b):

```C
// Begin    Time Analysis
temp a;     //  ---> 1
a = b;     // ---> 1
b = temp; // ---> 1
	     //  ---------
		//   f(n) = 3
	   //    O(1)

		/* 
		   Space Analysis
		   a ---> 1
		   b ---> 1
		   temp ---> 1
		   ------------
			  s(n) = 3
			  O(1)
		/*
// End
```

```C
x = 5 * a + 6 * b // ---> O(1)
```

###### How to analyze an algorithm?
 
1. **Time:** How long it will take?
2. **Space:** How much memory space it will consume?
3. **N/W:** How data transfer is done? 
4. **Power consumption:** How much power is consumed?
5. **CPU Registers:** How many registers is it consuming?

*Requirements depend on type of program.*

---

# Frequency Count Method

Algorithm sum(A,n)
```C
s = 0; // ---> 1

for(int i = 0; i < n; i++) { // ---> n+1
  s = s+A[i]; // ---> n
}
return s; // ---> 1

					/*
						--------------
						f(n) = 2n + 3  
						O(n)
					*/

/*
	Space Complexity
	A ---> n
	n ---> 1
	s ---> 1
	i ---> 1

------------
  S(n) = n+3
  O(n) 
*/
```

|  8    |   3   | 9     |   7   |  2    |
|:-----|:-----|:-----|:-----|:-----|
|    0  |  1    |     2 |   3   |   4   |

n = 5

---

Algorithm Add(A,B.n)
```C
for(int i = 0; i < n; i++) { // ---> n+1
	for(j = 0; j < n; j++) { // ---> n * (n+1)
		C[i,j] = A[i,j] + B[i,j]; // ---> n * n
														/*
															------------
														f(n) = 2n^2 + 2n + 1
														O(n^2)
														*/
	}
} 

/*
	Space Complexity
	A ---> n^2
	B ---> n^2
	C ---> n^2
	n ---> 1
	i ---> 1
	j ---> 1
------------
	s(n) = 3n^2 + 3
	O(n^2)

*/
```

n times n = n^2
n  times (n+1) = n^2 + n
n + 1 = n + 1

sum = n^2 + 2n^2 + n + n + 1 = **2n^2 + 2n + 1**

---

Algorithm Multiply(A,B,n)

```C
for(int i = 0; i < n; i++) { // ---> n+1
	for(int j = 0; j < n; j++) { // ---> n(n+1)
		c[i,j] = 0; // ---> n * n

		for(int k = 0; k < n; k++) { // ---> n*n(n+1)
			c[i,j] = c[i,j] + A[i,k] * B[k,j];
			// n * n * n
		}
	}
}

/*
	f(n) = 2n^3 + 3n^2 + 2n + 1
	O(n^3)

	Space Complexity
	A ---> n^2
	B ---> n^2
	C ---> n^2
	n ---> 1
	i ---> 1
	j ---> 1
	k ---> 1
	----------
	S(n) = 3n^2 + 4
	O(n^2)

	Time: O(n^3)
	Space: O(n^2)
*/
```

---

# Time Complexity #1 

```C
for(int i = 0; i < n; i++) { // n+1
	smthing; // n
}
					// O(n)
```

```C
for(i = n; i > 0 i--) { // order is still n
	smthing;
}
```

```C
for(i = 1; i < n; i = i+2) { 
	smthing; // n/2
}

					// O(n)
```

```C
for(i = 0; i < n; i++) {
	for(j = 0; j < i; j++) {
		smthing;
	}
}
```

![[Screenshot 2023-02-19 at 12.14.25 AM.png]]

---

```
p = 0;

for(i = 1; p <= n; i++) {
	p = p+i;
}
```

![[Screenshot 2023-02-19 at 12.21.11 AM.png]]
