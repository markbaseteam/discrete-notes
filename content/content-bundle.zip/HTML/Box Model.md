
Padding: 
- Used to add background to element to go around content 
Margin:
- Faces outside of border.
- Used to space two elements apart from each other