## Introduction


###### Chapter 3: [[Chapter 3 - Sets | Sets]]
  * 3.1: [[Chapter 3 - Sets#3.1 Sets and Subsets | Sets and Subsets]]
  * 3.2: [[Chapter 3 - Sets#3.2 Sets of Sets | Sets of Sets]]
  * 3.3: [[Chapter 3 - Sets#3.3 Union and Intersection | Union and Intersection]]
  * 3.4: [[Chapter 3 - Sets#3.4 More set operations | More set operations]]
  * 3.5 [[Chapter 3 - Sets#3.5 Set identities| Set Identities]]
  * 3.6 [[#3.6 Cartesian Products | Cartesian Products]]
  * 3.7 [[#3.7 Partitions | Partitions]]

---

# 3.1 Sets and Subsets

**Sets**: a collection of objects.
**Elements**: objects in a set.

objects may be of various types, such as titles of books, names of bridges, or rational numbers. This material is mostly concerned with sets of mathematical objects like numbers.

---

**roster notation**: a list of the elements enclosed in curly braces with the individual elements separated by commas.

Order is unimportant and repeating doesn't change the set
A = { 2, 4, 6, 10 } 
A = { 10, 6, 4, 2 }
A = { 2, 2, 4, 6, 10 }

---

###### Example 1

![[Screenshot 2023-01-28 at 5.44.52 PM.png]]

---

#### More notation related to sets

**Empty set / null set**: set with no elements 
- denoted by {} or the symbol ∅

**finite set**: set that is either empty or whose elements can be numbered 1 through n for some positive integer n.

**infinite set**: set that is not finite.

**cardinality**: denoted by [A], number of elements in A.
*  If A = { 2, 4, 6, 10 }, then |A| = 4.
* cardinality of the empty set |∅| is zero.

**definition:**
`` 2 ∈ X  = 2 is an element of X ``

---
###### Example 2

![[Screenshot 2023-01-28 at 5.51.03 PM.png]]

---
###### Common Mathematical sets 


![[Screenshot 2023-01-28 at 5.53.29 PM.png]]

###### Set Builder Notation

![[Screenshot 2023-01-28 at 10.32.08 PM.png]]

###### Subset

P is a subset of Q when every element in p is also present in Q
![[Screenshot 2023-01-28 at 10.21.53 PM.png]]

---

# 3.2 Sets of Sets

It is possible that the elements of a set are themselves sets.

For example: 
**A = { { 1, 2 }, ∅, { 1, 2, 3 }, { 1 } }**

The set A has four elements:
- {1, 2}
- ∅
- {1, 2, 3}
- { 1 }

Furthermore, { 1 } ⊈ A since 1 ∉ A.

---

###### Example 1
**B = { 2 , ∅, { 1, 2, 3 }, { 1 } }**

In this case,
2 ∈ B, but 1 ∉ B. Also, { 2 } ⊆ B, but { 1 } ⊈ B.

---
###### Example 2

![[Screenshot 2023-01-28 at 11.07.38 PM.png]]

---
#### Power set

The power set of a set A, denoted P(A), is the set of all subsets of A. 

For example, if A = { 1, 2, 3 }, then:
**P(A) = { ∅, { 1 }, { 2 }, { 3 }, { 1, 2 }, { 1, 3 }, { 2, 3 }, { 1, 2, 3 } }**

---

###### Example 1

![[Screenshot 2023-01-28 at 11.14.00 PM.png]]

Since |A| = 3, the cardinality of the power set of A is 23 = 8. Here is the general rule for the cardinality of a power set:

---
####  Theorem 3.2.1: Cardinality of a power set.

![[Screenshot 2023-01-28 at 11.22.43 PM.png]]

---
###### Example 1
![[Screenshot 2023-01-28 at 11.25.42 PM.png]]

---
###### Example 2 

Consider the following set:
A = { 2, 3, 5, 7, 14 }

size 0: ∅
size 1: {2}, {3}, {5}, {7}, {14}
size 2: {2, 3}, {2, 5}, {2, 7}, {2, 14}, {3, 5}, {3, 7}, {3, 14} {5, 7}, {5, 14}, {7, 14}
size 3: {2, 3, 5}, {2, 3, 7}, {2, 3, 14}, {3, 5, 7}, {3, 5, 14}, {5, 7, 14}
size 4: {2, 3, 5, 7}, {2, 3, 5, 14}, {3, 5, 7, 14}
size 5: {2, 3, 5, 7, 14}

$$P(A) = 5$$
$${| P(A)| = 2^n=2^5=32}$$

---

# 3.3 Union and Intersection

#### The set intersection operation

Let A and B be sets.

The intersection of A and B, denoted A ∩ B and read "A intersect B", is the set of all elements that are elements of both A and B.

![[Screenshot 2023-01-29 at 12.10.34 AM.png]]

---
# 3.4 More set operations

#### The set union operation

The union of two sets, A and B, denoted A ∪ B and read "A union B", is the set of all elements that are elements of A or B. The definition for union uses the inclusive or, meaning that if an element is an element of both A and B, then it is also an element of A ∪ B.

---
###### Example 1

![[Screenshot 2023-01-29 at 12.15.21 AM.png]]

---
#### Multiple set operations

Set operations can be combined to define even more sets. 

---

###### Example 1

![[Screenshot 2023-01-29 at 12.21.57 AM.png]]

----
###### Example 2

![[Screenshot 2023-01-29 at 12.24.25 AM.png]]

---
#### Special notation

![[Screenshot 2023-01-29 at 12.31.40 AM.png]]

---

###### Challenge problems within special notation

![[Screenshot 2023-01-29 at 12.55.51 AM.png]]

---

#### The set intersection operation

Let A and B be sets.

The intersection of A and B, denoted A ∩ B and read "A intersect B", is the set of all elements that are elements of both A and B.

![[Screenshot 2023-01-29 at 12.10.34 AM.png]]

---
#### The set union operation

The union of two sets, A and B, denoted A ∪ B and read "A union B", is the set of all elements that are elements of A or B. The definition for union uses the inclusive or, meaning that if an element is an element of both A and B, then it is also an element of A ∪ B.

---
###### Example 1

![[Screenshot 2023-01-29 at 12.15.21 AM.png]]

---
#### Multiple set operations

Set operations can be combined to define even more sets. 

---

###### Example 1

![[Screenshot 2023-01-29 at 12.21.57 AM.png]]

----
###### Example 2

![[Screenshot 2023-01-29 at 12.24.25 AM.png]]

---
#### Special notation

![[Screenshot 2023-01-29 at 12.31.40 AM.png]]

---

###### Challenge problems within special notation

![[Screenshot 2023-01-29 at 12.55.51 AM.png]]

---

# 3.5 Set identities 

The set operations intersection, union and complement are defined in terms of logical operations. All the elements are assumed to be contained in a universal set _U_.

###### Key definitions:
* ***∧**: AND
* ***∨**: OR
* ***¬**: NOT

---

-   x ∈ A ∩ B   ↔   (x ∈ A) ∧ (x ∈ B)
    
-   x ∈ A ∪ B   ↔   (x ∈ A) ∨ (x ∈ B)
    
-   x ∈ A   ↔   ¬(x ∈ A)

The sets _U_ and ∅ correspond to the constants true (T) and false (F):

-   x ∈ ∅   ↔   F
    
-   x ∈ U   ↔   T

**set identity**: an equation involving sets that is true regardless of the contents of the sets in the expression.

---

###### Example 1:

![[Screenshot 2023-01-30 at 4.53.50 PM.png]]

---
#### Table of Set identities

![[Screenshot 2023-01-30 at 4.58.18 PM.png]]

---

#### Prove the Identity Laws

![[Screenshot 2023-01-30 at 5.10.04 PM.png]]

###### Proper definition for b): 
> A intersection U is a set of all x such that x belongs to A and X belongs to U

---

#### Proving the Domination and Idempotent Laws

![[Screenshot 2023-01-30 at 5.30.14 PM.png]]

---

#### Proving the Double Complementation, Commutative, and Associative Laws

![[Screenshot 2023-01-30 at 5.51.38 PM.png]]

---

#### Proving the Distributive Laws

![[Screenshot 2023-01-30 at 6.05.16 PM.png]]

---

#### Proving the De Morgan's, Absorption, and Complement Laws

![[Screenshot 2023-01-30 at 7.22.48 PM.png]]![[Screenshot 2023-01-30 at 7.30.48 PM.png]]

> Must remember Idempotent law, Identity, etc...

---
# 3.6 Cartesian Products

An ordered pair of items is written (x, y). The first entry of the ordered pair (x, y) is x and the second entry is y. 

The use of parentheses ( ) for an ordered pair indicates that the order of entries is significant, unlike sets which use curly braces { }, indicating that the order in which the elements are listed does not matter.

For example, (x, y) ≠ (y, x) unless x = y. By contrast, {x, y} is equal to {y, x}, with both denoting the set consisting of elements x and y. Two ordered pairs (x, y) and (u, w) are equal if and only if x = u and y = w.

---

For two sets, A and B, the Cartesian product of A and B, denoted A x B, is the set of all ordered pairs in which the first entry is in A and the second entry is in B. That is:

				A x B = { (a, b) : a ∈ A and b ∈ B }

Since the order of the elements in a pair is significant, A x B will not be the same as B x A, unless A = B, or either A or B is empty. If A and B are finite sets, then |A x B| = |A|⋅|B|.

---

###### Example 1

![[Screenshot 2023-02-01 at 1.30.02 PM.png]]

---

An ordered list of three items is called an ordered triple and is denoted 
(x, y, z). For n ≥ 4, an ordered list of n items is called an ordered n-tuple (or just n-tuple for short). For example, (w, x, y, z) is an ordered 4-tuple and (u, w, x, y, z) is an ordered 5-tuple.

The Cartesian product of three sets contains ordered triples, and for n ≥ 4, the Cartesian product of n sets contains n-tuples. The Cartesian product of n sets, A1, A2, ..., An is

**A1 x A2 x ... x An = { (a1, a2, ... , an) : ai ∈ Ai for all i such that 1 ≤ i ≤ n }**

![[Screenshot 2023-02-01 at 1.56.00 PM.png]]

---
#### Strings

![[Screenshot 2023-02-01 at 1.59.08 PM.png]]

---

# 3.7 Partitions

#### Set Partitions

![[Screenshot 2023-02-01 at 3.04.40 PM.png]]

---

###### Example
![[Screenshot 2023-02-01 at 3.14.01 PM.png]]

---
