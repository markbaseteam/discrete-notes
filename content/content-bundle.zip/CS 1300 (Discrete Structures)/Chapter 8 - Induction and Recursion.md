
## Introduction

---

# 8.1 Sequences

![[Screenshot 2023-04-08 at 7.08.58 PM.png]]

---

#### Sequence basics

![[Screenshot 2023-04-08 at 7.11.11 PM.png]]

---

#### Increasing and decreasing sequences 

![[Screenshot 2023-04-08 at 7.17.40 PM.png]]

![[Screenshot 2023-04-08 at 7.18.55 PM.png]]

---

#### Geometric Sequences

A geometric sequence is a sequence of real numbers where each term after the initial term is found by taking the previous term and _multiplying_ by a fixed number called the common ratio. A geometric sequence can be finite or infinite.

![[Screenshot 2023-04-08 at 7.24.22 PM.png]]

![[Screenshot 2023-04-08 at 7.24.42 PM.png]]

---

#### Arithmetic sequences

![[Screenshot 2023-04-08 at 7.31.01 PM.png]]

![[Screenshot 2023-04-08 at 7.31.21 PM.png]]

---

# 8.2 Recurrence Relations

![[Screenshot 2023-04-08 at 7.39.12 PM.png]]

---

![[Screenshot 2023-04-08 at 7.45.18 PM.png]]
---

# 8.3 Summations

![[Screenshot 2023-04-08 at 7.43.55 PM.png]]

---
#### Computing Summations

![[Screenshot 2023-04-08 at 7.50.16 PM.png]]

---

#### Pulling out a final term from a summation

![[Screenshot 2023-04-08 at 7.53.33 PM.png]]

---

#### Change of variables in summations

![[Screenshot 2023-04-08 at 7.58.44 PM.png]]

![[Screenshot 2023-04-08 at 8.01.48 PM.png]]

---

#### Closed forms for sums

![[Screenshot 2023-04-08 at 8.05.47 PM.png]]

![[Screenshot 2023-04-08 at 8.05.56 PM.png]]

![[Screenshot 2023-04-08 at 8.06.07 PM.png]]

---

# 8.4 Mathematical induction

![[Screenshot 2023-04-15 at 5.02.46 PM.png]]

The **principle of mathematical induction** states that if the base case (for n = 1) is true and inductive step is true, then the theorem holds for all positive integers.

![[Screenshot 2023-04-15 at 5.03.44 PM.png]]

![[Screenshot 2023-04-15 at 5.08.04 PM.png]]

---

###### Example 1

![[Screenshot 2023-04-15 at 5.17.11 PM.png]]

---

# 8.5 More Inductive Proofs

![[Screenshot 2023-04-15 at 6.13.23 PM.png]]

---

![[Screenshot 2023-04-15 at 6.58.45 PM.png]]

![[Screenshot 2023-04-15 at 7.09.50 PM.png]]

![[Screenshot 2023-04-15 at 7.15.11 PM.png]]

---

# 8.6 Strong induction and well-ordering

![[Screenshot 2023-04-15 at 7.41.26 PM.png]]

![[Screenshot 2023-04-15 at 7.41.36 PM.png]]

---

###### Example 1

![[Screenshot 2023-04-15 at 7.54.14 PM.png]]

![[Screenshot 2023-04-15 at 7.54.28 PM.png]]