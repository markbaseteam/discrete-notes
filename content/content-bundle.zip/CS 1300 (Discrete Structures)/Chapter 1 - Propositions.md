## Introduction


###### Chapter 1: [[Chapter 1 - Propositions|  Propositions]]
* 1.1 [[Chapter 1 - Propositions#1.1 Propositions | Propositions]]
* 1.2 [[Chapter 1 - Propositions#1.2 Evaluating compound propositions | Evaluating compound propositions]]
* 1.3 [[Chapter 1 - Propositions#1.3 Conditional Statements | Conditional Statements]]
* 1.4 [[Chapter 1 - Propositions#1.4 Logical equivalence | Logical equivalence]]
* 1.5 [[Chapter 1 - Propositions#1.5 Laws of propositional logic | Laws of propositional logic]]
* 1.6 [[Chapter 1 - Propositions#1.6 Predicates and quantifiers | Predicates and quantifiers]]
* 1.7 [[Chapter 1 - Propositions#1.7 Quantified Statements | Quantified Statements]]
* 1.8 [[Chapter 1 - Propositions#1.8 De Morgan's law for quantified statements | De Morgan's Law for quantified statements]]
* 1.9 [[Chapter 1 - Propositions#1.9 Nested quantifiers] | Nested quantifiers]]
* 1.10 [[Chapter 1 - Propositions#1.10 More nested quantified statements | More nested quantified statements]]
* 1.11 [[Chapter 1 - Propositions#1.11 Logical Reasoning|Logical Reasoning]]
* 1.12 [[Chapter 1 - Propositions#1.12 Rules of inference with propositions|Rules of inference with propositions]]
* 1.13 [[Chapter 1 - Propositions#1.13 Rules of inference with quantifiers | Rules of inference with quantifiers]]

---

# 1.1 Propositions

**Logic:** is the study of formal reasoning. A statement in a spoken language, such as in English, is often ambiguous in its meaning. By contrast, a statement in logic always has a well defined meaning. Logic is important in mathematics for proving theorems.

The most basic element in logic is a proposition. A **proposition** is a statement that is either true or false.

A proposition's **truth value** is a value indicating whether the proposition is actually true or false.

A proposition is still a proposition whether its truth value is known to be true, known to be false, unknown, or a matter of opinion. The following are all propositions.

---

#### The conjunction operation

Propositional variables such as p, q, and r can be used to denote arbitrary propositions, as in:

p: January has 31 days.  
q: February has 33 days.

---

A **compound proposition** is created by connecting individual propositions with logical operations. A **logical operation** combines propositions using a particular composition rule. For example, the conjunction operation is denoted by ∧. The proposition p ∧ q is read "p and q" and is called the conjunction of p and q. p ∧ q is true if both p is true and q is true. p ∧ q is false if p is false, q is false, or both are false.

Using the definitions for p ∧ q given above, the proposition p ∧ q is expressed in English as:

p ∧ q: January has 31 days and February has 33 days.

Proposition p's truth value is true — January does have 31 days. Proposition q's truth value is false — February does not have 33 days. The compound proposition p ∧ q is therefore false, because it is not the case that both propositions are true.

A **truth table** shows the truth value of a compound proposition for every possible combination of truth values for the variables contained in the compound proposition. Every row in the truth table shows a particular truth value for each variable, along with the compound proposition's corresponding truth value. Below is the truth table for p ∧ q, where T represents true and F represents false.

---
###### Example 1

![[Screenshot 2023-02-04 at 5.52.22 PM.png]]

---

#### Different ways to express a conjunction in English

Define the propositional variables p and h as:

p: The sauce looks disgusting.  
h: The sauce tastes delicious.

There are many ways to express the proposition p ∧ h in English. The sentences below have slightly different meanings in English but correspond to the same logical meaning.

![[Screenshot 2023-02-04 at 5.56.07 PM.png]]

---

#### The disjunction operation

The **disjunction operation** is denoted by ∨. The proposition p ∨ q is read "p or q", and is called the **disjunction** of p and q. p ∨ q is true if either one of p or q is true, or if both are true. The proposition p ∨ q is false only if both p and q are false. 

Using the same p and q from the example above, p ∨ q is the statement:

p ∨ q: January has 31 days or February has 33 days.

The proposition p ∨ q is **true** because January does have 31 days. The truth table for the ∨ operation is given below.

![[Screenshot 2023-02-04 at 5.58.17 PM.png]]

---
#### Ambiguity of "or" in English

![[Screenshot 2023-02-04 at 6.00.54 PM.png]]

---

The **negation operation** acts on just one proposition and has the effect of reversing the truth value of the proposition. The negation of proposition p is denoted **¬p** and is read as **"not p"**. Since the negation operation only acts on a single proposition, its truth table only has two rows for the proposition's two possible truth values.

![[Screenshot 2023-02-04 at 6.06.10 PM.png]]

---

# 1.2 Evaluating compound propositions

A compound proposition can be created by using more than one operation. For example, the proposition p ∨ ¬q evaluates to true if p is true or the negation of q is true.

The order in which the operations are applied in a compound proposition such as p ∨ ¬q ∧ r may affect the truth value of the proposition. In the absence of parentheses, the rule is that negation is applied first, then conjunction, then disjunction:

![[Screenshot 2023-02-04 at 6.11.21 PM.png]]

---
![[Screenshot 2023-02-04 at 6.12.02 PM.png]]

---
###### Example 1

![[Screenshot 2023-02-04 at 6.13.38 PM.png]]

---
#### Filling in the rows of a truth table

![[Screenshot 2023-02-04 at 6.18.16 PM.png]]

---
###### Example

![[Screenshot 2023-02-04 at 6.22.47 PM.png]]

---

When filling out a truth table for a complicated compound proposition, completing intermediate columns for smaller parts of the full compound proposition can be helpful.

![[Screenshot 2023-02-04 at 6.27.13 PM.png]]

---

# 1.3 Conditional Statements

The **conditional operation** is denoted with the symbol →. The proposition p → q is read "if p then q". The proposition p → q is false if p is true and q is false; otherwise, p → q is true.

A **compound proposition** that uses a conditional operation is called a conditional proposition. A conditional proposition expressed in English is sometimes referred to as a conditional statement, as in "If there is a traffic jam today, then I will be late for work."

**p → q**, the proposition p is called the hypothesis.
 
the proposition **q** is called the conclusion. 
 
The truth table for p → q is given below:

![[Screenshot 2023-02-04 at 6.51.59 PM.png]]

---
###### Example 1 of conditional statement

![[Screenshot 2023-02-04 at 6.52.56 PM.png]]

---

There are many ways to express the conditional statement p → q in English:

![[Screenshot 2023-02-04 at 7.00.39 PM.png]]

---

#### The converse, contrapositive, and inverse

Three conditional statements related to proposition p → q are so common that they have special names. 

The converse of p → q is q → p.

The contrapositive of p → q is ¬q → ¬p.

The inverse of p → q is ¬p → ¬q.

![[Screenshot 2023-02-04 at 7.06.04 PM.png]]

---

#### The biconditional operation

![[Screenshot 2023-02-04 at 7.07.33 PM.png]]

---

#### Compound propositions with conditional and biconditional operations

The conditional and biconditional operations can be combined with other logical operations, as in (p → q) ∧ r.

If parentheses are not used to explicitly indicate the order in which the operations should be applied, then ∧, ∨, and ¬ should be applied before → or ↔. 

Thus, the proposition p → q ∧ r should be evaluated as p → (q ∧ r). Good practice, however, is to use parentheses so that the order of operations is clear.

![[Screenshot 2023-02-04 at 7.15.10 PM.png]]

---

# 1.4 Logical equivalence

  
A compound proposition is a **tautology** if the proposition is always true, regardless of the truth value of the individual propositions that occur in it.

A compound proposition is a **contradiction** if the proposition is always false, regardless of the truth value of the individual propositions that occur in it.

The proposition p ∨ ¬p is a simple example of a tautology since the proposition is always true whether p is true or false.

![[Screenshot 2023-02-08 at 2.20.34 PM.png]]

Similarly, the proposition p ∧ ¬p is an example of a simple contradiction, because the proposition is false regardless of whether p is true or false.

![[Screenshot 2023-02-08 at 2.21.12 PM.png]]

---

#### Showing logical equivalence using truth tables

Two compound propositions are said to be **logically equivalent** if they have the same truth value regardless of the truth values of their individual propositions.

If s and r are two compound propositions, the notation s ≡ r is used to indicate that r and s are logically equivalent. 

For example, p and ¬¬p have the same truth value regardless of whether p is true or false, so p ≡ ¬¬p. 

Propositions s and r are logically equivalent if and only if the proposition s ↔ r is a tautology. Note that s ≡ r if and only if r ≡ s.

---

###### Showing p →¬p ≡¬p with a truth table

![[Screenshot 2023-02-08 at 2.43.28 PM.png]]

---

###### Truth table to show:   ¬p ∨ ¬q ≡ ¬(p ∧ q).

![[Screenshot 2023-02-08 at 2.45.02 PM.png]]

---

#### De Morgan's laws

**De Morgan's laws** are logical equivalences that show how to correctly distribute a negation operation inside a parenthesized expression. 

Both versions of De Morgan's laws are particularly useful in logical reasoning. 

The first De Morgan's law is:

					¬(p ∨ q)   ≡   (¬p ∧ ¬q)

When the negation operation is distributed inside the parentheses, the disjunction operation changes to a conjunction operation. 

Consider an English example with the following propositions for p and q.

---

The second version of De Morgan's law swaps the role of the disjunction and conjunction:

					¬(p ∧ q)   ≡   (¬p ∨ ¬q)

---

# 1.5 Laws of propositional logic

If two propositions are logically equivalent, then one can be substituted for the other within a more complex proposition. 

The compound proposition after the substitution is logically equivalent to the compound proposition before the substitution.

For example **p → q ≡ ¬p ∨ q**. Therefore,

(p ∨ r) ∧ (**¬p ∨ q**)  ≡  (p ∨ r) ∧ (**p → q**)

---

In the next example, the logical equivalence p → q ≡ ¬p ∨ q is applied where the variables p and q represent compound propositions:

(¬t ∧ r) **→** (¬s ∨ t)  ≡  **¬**(¬t ∧ r ) **∨** (¬s ∨ t)

---

#### Using the laws of propositional logic to show logical equivalence

Substitution gives an alternate way of showing that two propositions are logically equivalent.

If one proposition can be obtained from another by a series of substitutions using equivalent expressions, then the two propositions are logically equivalent. 

The table below shows several laws of propositional logic that are particularly useful for establishing the logical equivalence of compound propositions:

![[Screenshot 2023-02-11 at 5.26.48 PM.png]]

---

###### Example 1

![[Screenshot 2023-02-11 at 6.55.47 PM.png]]

---

###### Example 2

![[Screenshot 2023-02-11 at 7.03.22 PM.png]]

---

# 1.6 Predicates and quantifiers

Many mathematical statements contain variables. The statement "x is an odd number" is not a proposition because the statement does not have a well-defined truth value until the value of x is specified.

If x = 5, the statement is true. If x = 4, the statement is false. The truth value of the statement can be expressed as a function P of the variable x, as in P(x). The expression P(x) is read "P of x".

 A logical statement whose truth value is a function of one or more variables is called a predicate. If P(x) is defined to be the statement "x is an odd number", then P(5) corresponds to the statement "5 is an odd number". P(5) is a proposition because it has a well defined truth value.
 
![[Screenshot 2023-02-11 at 8.11.50 PM.png]]

---

#### Universal quantifier 

![[Screenshot 2023-02-11 at 8.21.06 PM.png]]

A **counterexample** for a universally quantified statement is an element in the domain for which the predicate is false. 

A single counterexample is sufficient to show that a universally quantified statement is false. 

For example, consider the statement ∀x (x2 > x), in which the domain is the set of positive integers. 

When x = 1, then x2 = x and the statement x2 > x is not true. Therefore x = 1 is a counterexample that shows the statement "∀x (x2 > x)" is false.

---

#### Existential quantifier

![[Screenshot 2023-02-11 at 8.23.20 PM.png]]

---

# 1.7 Quantified Statements

Universally and existentially quantified statements can also be constructed from logical operations. Consider an example in which the domain is the set of positive integers and define the following predicates:

-   P(x): x is prime
    
-   O(x): x is odd

The proposition ∃x (P(x) ∧ ¬O(x)) states that there exists a positive number that is prime and not odd. This proposition is true because of the example x = 2. Since 2 is prime and not odd, the statement P(2) ∧ ¬O(2) is true.

The proposition ∀x (P(x) → O(x)) says that for every positive integer x, if x is prime then x is odd. This proposition is false, because of the counterexample x = 2. Since 2 is prime and not odd, the conditional statement P(2) → O(2) is false.

The universal and existential quantifiers are generically called quantifiers.

A logical statement that includes a universal or existential quantifier is called a quantified statement. The quantifiers ∀ and ∃ are applied before the logical operations (∧, ∨, →, and ↔) used for propositions.

This means that the statement ∀x P(x) ∧ Q(x) is equivalent to (∀x P(x)) ∧ Q(x) as opposed to ∀x (P(x) ∧ Q(x)).

---

A variable x in the predicate P(x) is called a **free variable** because the variable is free to take on any value in the domain. 

The variable x in the statement ∀x P(x) is a **bound variable** because the variable is bound to a quantifier. A statement with no free variables is a proposition because the statement's truth value can be determined.

In the statement (∀x P(x)) ∧ Q(x), the variable x in P(x) is bound by the universal quantifier, but the variable x in Q(x) is not bound by the universal quantifier. 

Therefore the statement (∀x P(x)) ∧ Q(x) is not a proposition. In contrast, the universal quantifier in the statement ∀x (P(x) ∧ Q(x)) binds both occurrences of the variable x. Therefore ∀x (P(x) ∧ Q(x)) is a proposition.

---

####  Logical equivalence with quantified statements

Two quantified statements (whether they are expressed in English or the language of logic) have the same logical meaning if they have the same truth value regardless of value of the predicates for the elements in the domain. Consider as an example a domain consisting of a set of people invited to a party. Define the predicates:

-   P(x): x came to the party
    
-   S(x): x was sick

The statement "Everyone was not sick" is logically equivalent to "∀x ¬S(x)" because the two statements have the same truth value regardless of who was invited to the party and whether they were sick.

The table below gives an example of a set of people who could have been invited to the party and the value of the predicate S(x) and P(x) for each person. For example, Gertrude came to the party (i.e., P(Gertrude) = T) because the truth value in the row labeled Gertrude and column labeled P(x) is true.

![[Screenshot 2023-02-13 at 11.16.02 PM.png]]

For the group of people in the domain, the statement "Someone was sick and came to the party" is false because there is no individual for whom S(x) and P(x) are true. However, ∃x (S(x) ∨ P(x)) is true because, for example, S(Joe) ∨ P(Joe) is true. Therefore the two statements "Someone was sick and came to the party" and "∃x (S(x) ∨ P(x))" are not logically equivalent.

---

# 1.8 De Morgan's law for quantified statements

The negation operation can be applied to a quantified statement, such as ¬∀x F(x). If the domain for the variable x is the set of all birds and the predicate F(x) is "x can fly", then the statement ¬∀x F(x) is equivalent to:

"Not every bird can fly."

which is logically equivalent to the statement:

"There exists a bird that cannot fly."

The equivalence of the previous two statements is an example of De Morgan's law for quantified statements, which is formally stated as ¬∀x F(x) ≡ ∃x ¬F(x). 

The diagram below illustrates that for a finite domain, De Morgan's law for universally quantified statements is the same as De Morgan's law for propositions:

![[Screenshot 2023-02-13 at 11.41.52 PM.png]]

---

Similarly, consider the statement ¬∃x A(x) in which the domain is the set of children enrolled in a class and A(x) is the predicate "x is absent today". The statement is expressed in English as:

"It is not true that there is a child in the class who is absent today."

which is logically equivalent to:

"Every child enrolled in the class is not absent today."

The logical equivalence of the last two statements is an example of the second of De Morgan's laws for quantified statements: ¬∃x P(x) ≡ ∀x ¬P(x).

The diagram below illustrates that for a finite domain, De Morgan's law for existentially quantified statements is the same as De Morgan's law for propositions:

![[Screenshot 2023-02-13 at 11.43.15 PM.png]]

![[Screenshot 2023-02-13 at 11.43.29 PM.png]]

---

#### De Morgan's law can be used to simplify an existentially quantified statement.

![[Screenshot 2023-02-13 at 11.44.46 PM.png]]

![[Screenshot 2023-02-13 at 11.46.48 PM.png]]

---

# 1.9 Nested quantifiers 
  
If a predicate has more than one variable, each variable must be bound by a separate quantifier. 

A logical expression with more than one quantifier that binds different variables in the same predicate is said to have **nested quantifiers**. 

The examples below show several logical expressions and which variables are bound in each. The logical expression is a proposition if all the variables are bound.

![[Screenshot 2023-02-18 at 5.06.21 PM.png]]

---

#### Nested quantifiers of the same type

Consider a scenario where the domain is a group of people who are all working on a joint project. Define the predicate M to be:

M(x, y): x sent an email to y

and consider the proposition: ∀x ∀y M(x, y). The proposition can be expressed in English as:

∀x ∀y M(x, y)   ↔   "Everyone sent an email to everyone."

The statement ∀x ∀y M(x, y) is true if for every pair, x and y, M(x, y) is true. The universal quantifiers include the case that x = y, so if ∀x ∀y M(x, y) is true, then everyone sent an email to everyone else and everyone sent an email to himself or herself. The statement ∀x ∀y M(x, y) is false if there is any pair, x and y, that causes M(x, y) to be false. In particular, ∀x ∀y M(x, y) is false even if there is a single individual who did not send himself or herself an email.

Now consider the proposition: ∃x ∃y M(x, y). The proposition can be expressed in English as:

∃x ∃y M(x, y)   ↔   "There is a person who sent an email to someone."

The statement ∃x ∃y M(x, y) is true if there is a pair, x and y, in the domain that causes M(x, y) to evaluate to true. In particular, ∃x ∃y M(x, y) is true even in the situation that there is a single individual who sent an email to himself or herself. The statement ∃x ∃y M(x, y) is false if all pairs, x and y, cause M(x, y) to evaluate to false.

---

#### Alternating nested quantifiers

A quantified expression can contain both types of quantifiers as in: ∃x ∀y M(x, y). The quantifiers are applied from left to right, so the statement ∃x ∀y M(x, y) translates into English as:

∃x ∀y M(x, y)   ↔   "There is a person who sent an email to everyone."

Switching the quantifiers changes the meaning of the proposition:

∀x ∃y M(x, y)   ↔   "Every person sent an email to someone."

---

In reasoning whether a quantified statement is true or false, it is useful to think of the statement as a two player game in which two players compete to set the statement's truth value. One of the players is the "existential player" and the other player is the "universal player". The variables are set from left to right in the expression. The table below summarizes which variables are set by which player and the goal of each player:

![[Screenshot 2023-02-18 at 5.25.07 PM.png]]

If the predicate is true after all the variables are set, then the quantified statement is true. If the predicate is false after all the variables are set, then the quantified statement is false. Consider as an example the following quantified statement in which the domain is the set of all integers:

∀x ∃y (x + y = 0)

The universal player first selects the value of x. Regardless of which value the universal player selects for x, the existential player can select y to be -x, which will cause the sum x + y to be 0. Because the existential player can always succeed in causing the predicate to be true, the statement ∀x ∃y (x + y = 0) is true.

Switching the order of the quantifiers gives the following statement:

∃x ∀y (x + y = 0)

Now, the existential player goes first and selects a value for x. Regardless of the value chosen for x, the universal player can select some value for y that causes the predicate to be false. For example, if x is an integer, then y = -x + 1 is also an integer and x + y = 1 ≠ 0. Thus, the universal player can always win and the statement ∃x ∀y (x + y = 0) is false.

---

###### Example 1

![[Screenshot 2023-02-18 at 5.28.05 PM.png]]

---

####  De Morgan's law with nested quantifiers

De Morgan's law can be applied to logical statements with more than one quantifier. 

Each time the negation sign moves past a quantifier, the quantifier changes type from universal to existential or from existential to universal:


![[Screenshot 2023-02-18 at 5.30.56 PM.png]]

Consider a scenario in which the domain is the set of all students in a school. The predicate L(x, y) indicates that x likes y. The statement ∃x ∀y L(x, y ) is read as:

∃x ∀y L(x, y )   ↔   There is a student who likes everyone in the school.

The negation of the statement is:

¬∃x ∀y L(x, y )   ↔   There is no student who likes everyone in the school.

Applying De Morgan's laws yields: ¬∃x ∀y L(x, y ) ≡ ∀x ∃y ¬L(x, y ) which is translated into:

∀x ∃y ¬L(x, y )   ↔   Every student in the school has someone that they do not like.

---

###### Example 2

![[Screenshot 2023-02-18 at 5.35.41 PM.png]]

---

# 1.10 More nested quantified statements

#### Using logic to express "everyone else"

Consider a scenario where the domain is a group of people who are all working on a joint project. Define the predicate M(x, y) that indicates whether x sent an email to y. The statement ∀x ∀y M(x, y) asserts that every person sent an email to every other person and every person sent an email to himself or herself. How could we use logic to express that everyone sent an email to everyone else without including the case that everyone sent an email to himself or herself? The idea is to use the conditional operation: (x ≠ y) → M(x, y).

The table below shows a group of four people and the truth value of M(x, y) for each pair. For example, Agnes sent an email to Fred (i.e., M(Agnes, Fred) = T) because the truth value in the row labeled Agnes and the column labeled Fred is T.

![[Screenshot 2023-02-18 at 6.22.05 PM.png]]

The statement ∀x ∀y M(x, y) is false because M(Fred, Fred) and M(Marge, Marge) are both false. However, the statement

∀x ∀y ((x ≠ y) → M(x, y))

is true. The statement says that for every pair, x and y, if x and y are different people then x sent an email to y. That is, everyone sent an email to everyone else. The statement is true for the table above because for every pair that is not on the diagonal of the table (i.e., for every pair such that x ≠ y), M(x, y) is true.

---

#### Expressing uniqueness in quantified statements

An existentially quantified statement evaluates to true even if there is more than one element in the domain that causes the predicate to evaluate to true. If the domain is a set of people who attend a meeting and the predicate L(x) indicates whether or not x came late to the meeting, then the statement ∃x L(x) is true if there are one, two or more people who came late.

![[Screenshot 2023-02-18 at 6.28.48 PM.png]]

---

#### Moving quantifiers in logical statements

Now consider a set of people at a party as the domain. We would like to find a logical expression that is equivalent to the statement: "Every adult is married to someone at the party." There are two predicates:

M(x, y): x is married to y.  
A(x): x is an adult.

Here is an equivalent statement that is closer in form to a logical expression: "For every person x, if x is an adult, then there is a person y to whom x is married." The logic is expressed as:

∀x (A(x) → ∃y M(x, y))

Since y does not appear in the predicate A(x), "∃y" can be moved to the left so that it appears just after the ∀x resulting in the following equivalent expression:

∀x ∃y(A(x) → M(x, y))

Note a quantifier can not be moved in front of another quantifier without changing the meaning of the expression. For example, ∀x ∃y(A(x) → M(x, y)) is not logically equivalent to ∃y ∀x(A(x) → M(x, y)).

---

###### Example 1

![[Screenshot 2023-02-18 at 6.46.08 PM.png]]

---

###### Confusing stuff

![[Screenshot 2023-02-18 at 7.25.56 PM.png]]

![[Screenshot 2023-02-18 at 7.35.25 PM.png]]

![[Screenshot 2023-02-18 at 7.38.21 PM.png]]

---

# 1.11 Logical Reasoning

The language of logic allows us to formally establish the truth of logical statements, assuming that a set of hypotheses is true. 

An argument is a sequence of propositions, called hypotheses, followed by a final proposition, called the conclusion.

An argument is valid if the conclusion is true whenever the hypotheses are all true, otherwise the argument is invalid.

The argument is valid whenever the proposition ( p1 ∧ p2 ∧ … ∧ pn ) → c is a tautology.

An argument will be denoted as:

![[Screenshot 2023-02-25 at 9.59.39 PM.png]]

---

# Example 1

![[Screenshot 2023-02-25 at 10.05.12 PM.png]]

---

![[Screenshot 2023-02-25 at 10.07.33 PM.png]]

---

# The form of an argument

The hypotheses and conclusion in a logical argument can also be expressed in English, as in:

![[Screenshot 2023-02-25 at 10.09.38 PM.png]]

---

![[Screenshot 2023-02-25 at 10.12.25 PM.png]]

---

# 1.12 Rules of inference with propositions

  
Using truth tables to establish the validity of an argument can become tedious, especially if an argument uses a large number of variables. 

Fortunately, some arguments can be shown to be valid by applying rules that are themselves arguments that have already been shown to be valid. The laws of propositional logic can also be used in establishing the validity of an argument.

![[Screenshot 2023-02-25 at 11.36.08 PM.png]]

![[Screenshot 2023-02-25 at 11.37.05 PM.png]]

---

# Example 1

![[Screenshot 2023-02-25 at 11.40.52 PM.png]]

---

![[Screenshot 2023-02-26 at 12.47.58 AM.png]]

---

# 1.13 Rules of inference with quantifiers

![[Screenshot 2023-02-26 at 1.17.25 AM.png]]

![[Screenshot 2023-02-26 at 1.20.15 AM.png]]

---

The rules **existential instantiation** and **universal instantiation** replace a quantified variable with an element of the domain.

The rules **existential generalization** and **universal generalization** replace an element of the domain with a quantified variable. 

Note that the rules only apply to non-nested quantifiers. Applying the rules of inference to nested quantifiers would require more constraints on which rules could be applied in particular situations.

---

#### Rules of inference for quantified statements

![[Screenshot 2023-02-26 at 1.30.28 AM.png]]

---

###### Example 1

![[Screenshot 2023-02-26 at 1.34.31 AM.png]]

---

#### Rules to understand

![[Screenshot 2023-02-26 at 1.48.30 AM.png]]

![[Screenshot 2023-02-26 at 1.52.29 AM.png]]

![[Screenshot 2023-02-26 at 1.57.14 AM.png]]

![[Screenshot 2023-02-26 at 1.59.42 AM.png]]

**Universal generalization**: This step replaces an element with a variable. In universal generalization, an arbitrary element must be used.

**Universal instantiation**: This step replaces a variable with an element, indicating that the rule used is instantiation. In universal instantiation, the variable can be replaced by any element introduced earlier in the proof.

**Existential instantiation**: This step replaces a variable with an element of the domain, indicating that the rule used is instantiation. In existential instantiation, a particular element is introduced that replaces the variable.

Universal instantiation: c is an arbitrary element of the domain

Existential instantiation: c is a particular element 



---

#### Multiple uses of existential instantiation: a common mistake

It is important to define a new particular element with a new name for each use of existential instantiation within the same logical proof in order to avoid a faulty proof that an invalid argument is valid.

The mistake in the proof below is in the assumption that the value c (introduced in Step 2), which causes P(x) to be true, is the same value c (introduced in Step 5) that causes Q(x) to be true. A correct use of existential instantiation in line 4 would first introduce a new particular element, d that is not necessarily equal to c, and assert that Q(d) is true. For example, if P(x) means that x owns a cat and Q(x) means that x owns a dog, then the two hypotheses say that there is someone who owns a cat and there is someone who owns a dog. However, the two hypotheses together do not imply that there is someone who owns a cat and a dog.

---

#### Showing an argument with quantified statements is invalid

![[Screenshot 2023-02-26 at 2.32.51 AM.png]]

