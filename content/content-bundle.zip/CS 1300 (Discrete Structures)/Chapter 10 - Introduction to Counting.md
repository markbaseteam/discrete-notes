## Introduction

---

# 10.1 - Sum and Product Rules

![[Screenshot 2023-04-22 at 2.09.58 AM.png]]

![[Screenshot 2023-04-22 at 2.17.24 AM.png]]

![[Screenshot 2023-04-22 at 2.17.59 AM.png]]

![[Screenshot 2023-04-22 at 2.23.41 AM.png]]

![[Screenshot 2023-04-22 at 2.25.08 AM.png]]

---

# 10.2 The bijection rule

![[Screenshot 2023-04-22 at 2.42.39 AM.png]]

![[Screenshot 2023-04-22 at 2.45.45 AM.png]]

![[Screenshot 2023-04-22 at 2.50.00 AM.png]]

---

# 10.3 The generalized product rule

![[Screenshot 2023-04-22 at 2.59.34 AM.png]]

![[Screenshot 2023-04-22 at 3.06.08 AM.png]]

![[Screenshot 2023-04-22 at 3.06.01 AM.png]]

---

# 10.4 Counting permutations

![[Screenshot 2023-04-22 at 3.40.51 AM.png]]

![[Screenshot 2023-04-22 at 3.42.44 AM.png]]

![[Screenshot 2023-04-22 at 3.45.02 AM.png]]

![[Screenshot 2023-04-22 at 3.49.40 AM.png]]

![[Screenshot 2023-04-22 at 4.03.08 AM.png]]

![[Screenshot 2023-04-22 at 4.03.55 AM.png]]

---

# 10.5 Counting subsets

![[Screenshot 2023-04-28 at 3.55.39 PM.png]]

![[Screenshot 2023-04-28 at 4.06.55 PM.png]]

![[Screenshot 2023-04-28 at 4.24.18 PM.png]]

![[Screenshot 2023-04-28 at 4.28.22 PM.png]]

![[Screenshot 2023-04-28 at 4.31.39 PM.png]]

---

# 10.6 Subset and permutation examples

![[Screenshot 2023-04-29 at 3.07.45 PM.png]]

If the prizes are all different from each other, then the problem is asking about the number of 4-permutations from a set of 10 elements because the order in which prizes are distributed is important. If the prizes are all identical, then the problem is asking about the number of 4-subsets because the order in which prizes are distributed is not important.

---
