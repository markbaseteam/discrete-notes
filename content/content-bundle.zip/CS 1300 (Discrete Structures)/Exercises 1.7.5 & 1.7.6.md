### 1.7.5

M(X) = person x came to meeting on time
O(X) = person x is officer of club
D(X) = person x paid club dues

a) Someone is not an officer 
- **Logical expression**: ∃x ¬O(x) because the keyword "Someone" points to existential quantifier and ¬O(x) means person x is not the officer of club.

b) All the officers came on time to the meeting.
- **Logical expression**: ∀x (O(x) → M(x)) because the keyword "All" points to the universal quantifier and O(x) → M(x) means "if x are officers, they came to the meeting on time".

c) Everyone was on time for the meeting.
- **Logical expression**: ∀x M(x) because the keyword "Everyone" points to the universal quantifier and M(x) means person x came to the meeting on time.

d) Everyone paid their dues or came on time to the meeting.
- **Logical expression**: ∀x (D(x) ∨ M(x)) because the keyword "Everyone" points to the universal quantifier and (D(x) ∨ M(x)) means "person x paid club dues or person x came to the meeting on time".

e) At least one person paid their dues and came on time to the meeting.
- **Logical expression**: ∃x (D(x) ∧ M(x)) because the keyword "At least one" points to the existential quantifier being used and D(x) ∧ M(x) means "person x paid club dues or person x came to the meeting on time."

f) There is an officer who did not come on time for the meeting.
- **Logical expression**: ∃x (O(x) ∧ ¬M(x)) because the keyword "There is an officer" hints that it is not everyone which points to the existential quantifier being used and O(x) ∧ ¬M(x) stands for "person x is an officer and person x is not coming to the meeting on time".

---

### 1.7.6

A(x) = x is on the board of directors. (Note: members of the board of directors are also employees.)
E(x) = x earns more than $100,000
W(x) = x works more than 60 hours per week

a) ∀x (A(x) → E(x))
- **Logical expression**: Everyone who is on the board of directors earns more than $100,000.

b) ∃x (E(x) ∧ ¬W(x))
- **Logical expression**: Someone earns more than $100,000, but  doesn't work more than 60 hours per week.

c) ∀x (W(x) → E(x))
- **Logical expression**: Everyone who works more than 60 hours per week earns more than $100,000.

d) ∃x (¬A(x) ∧ E(x))
- **Logical expression**: Someone is not on the board of directors, but earns more than $100,000.

e) ∀x (E(x) → (A(x) ∨ W(x)))
- **Logical expression**: Everyone who earns more than $100,000 is either on the board of directors or works more than 60 hours per week.

f) ∃x (A(x) ∧ ¬E(x) ∧ W(x))
- **Logical expression**: Someone is on the board of directors and isn't earning $100,000 and works more than 60 hours per week.

