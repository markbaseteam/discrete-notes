## Introduction

---

# 4.1 Definition of Functions

![[Screenshot 2023-04-02 at 3.35.35 PM.png]]

If f maps an element of the domain to zero elements or more than one element of the target, then f is not **well-defined.**

If f is a function mapping X to Y and X is a finite set, then the function f can be specified by listing the pairs (x, y) in f. Alternatively, a function with a finite domain can be expressed graphically as an arrow diagram. In an arrow diagram for a function f, the elements of the domain X are listed on the left and the elements of the target Y are listed on the right. There is an arrow from x ∈ X to y ∈ Y if and only if (x, y) ∈ f. Since f is a function, each x ∈ X has exactly one y ∈ Y such that (x, y) ∈ f, which means that in the arrow diagram for a function, there is exactly one arrow pointing out of every element in the domain.

---

###### Example 1

![[Screenshot 2023-04-02 at 3.38.04 PM.png]]

---

For function f: X → Y, an element y is in the range of f if and only if there is an x ∈ X such that (x, y) ∈ f. Expressed in set notation:

Range of f = { y: (x, y) ∈ f, for some x ∈ X }

The range of f is a subset of the target but the range is not necessarily equal to the target. In an arrow diagram, the range is the set of elements in the target that have arrows coming into them.

---

###### Recognizing well-defined functions

![[Screenshot 2023-04-02 at 3.41.51 PM.png]]

![[Screenshot 2023-04-02 at 3.42.08 PM.png]]

---

Target = right side
Domain = left side

---

A mathematical function f is often defined by describing how f acts on an input x, as in:

f(x) = x^2 − 2.

However, the definition is not complete until the domain and target of f are specified. For example:

g: **R** → **R**, where g(x) = |x|.

Note that g maps every real number to a real number. However, g does not map any number to a negative number.

---

#### Function Equality

Two functions, f and g, are equal if f and g have the same domain and target, and f(x) = g(x) for every element x in the domain. 

The notation f = g is used to denote the fact that functions f and g are equal:

---

# 4.2 Floor and ceiling functions

![[Screenshot 2023-04-02 at 4.00.57 PM.png]]

---

###### Computing the floor and ceiling functions

![[Screenshot 2023-04-02 at 4.02.59 PM.png]]

---

# 4.3 Properties of Functions

![[Screenshot 2023-04-02 at 4.10.29 PM.png]]

![[Screenshot 2023-04-02 at 4.12.07 PM.png]]

![[Screenshot 2023-04-02 at 4.12.59 PM.png]]

![[Screenshot 2023-04-02 at 4.13.16 PM.png]]

![[Screenshot 2023-04-02 at 4.13.52 PM.png]]

---

![[Screenshot 2023-04-02 at 4.19.37 PM.png]]

---

# 4.4 The Inverse of a Function

If a function f: X → Y is a bijection, then the inverse of f is obtained by exchanging the first and second entries in each pair in f. The inverse of f is denoted by f-1:

f-1 = { (y, x) : (x, y) ∈ f }.

Reversing each pair in a function f does not always result in a well-defined function. Therefore, some functions do not have an inverse. A function f: X → Y has an inverse if and only if reversing each pair in f results in a well-defined function from Y to X. f-1 is a well-defined function if every element in Y is mapped to exactly one element in X.

---

![[Screenshot 2023-04-02 at 4.33.08 PM.png]]

The reasoning above also applies to functions with infinite domains, and can be summed up in the following statement:

**A function f has an inverse if and only if f is a bijection**

---

The inverse of a bijection f can also be expressed in function notation. If f is a bijection from X to Y, then for every x ∈ X and y ∈ Y,

f(x) = y    if and only if    f-1(y) = x.

Therefore the value of f-1(y) is the unique element x ∈ X such that f(x) = y. If f-1 is the inverse of function f, then for every element x ∈ X, f-1(f(x)) = x.

---

#### Solving for the inverse of a function analytically.

When a function is defined on an infinite domain, it is sometimes possible to solve for the function's inverse analytically, as illustrated in the following animation:

![[Screenshot 2023-04-02 at 4.50.20 PM.png]]

---

![[Screenshot 2023-04-02 at 4.51.18 PM.png]]

---

# 4.5.1 Compositions of Functions

![[Screenshot 2023-04-02 at 5.21.16 PM.png]]

---

![[Screenshot 2023-04-02 at 5.24.44 PM.png]]

---

![[Screenshot 2023-04-02 at 5.27.28 PM.png]]

---
#### Composition of a function and its inverse.

![[Screenshot 2023-04-02 at 5.59.35 PM.png]]

---

# 4.6 Logarithms and exponents

![[Screenshot 2023-04-02 at 6.18.48 PM.png]]

---

#### Properties of Log

![[Screenshot 2023-04-02 at 6.24.55 PM.png]]

![[Screenshot 2023-04-02 at 6.25.14 PM.png]]

---

![[Screenshot 2023-04-02 at 6.38.30 PM.png]]

---

#### Divide and Conquer

![[Screenshot 2023-04-02 at 6.43.34 PM.png]]

---
###### Example 1

![[Screenshot 2023-04-02 at 6.45.56 PM.png]]