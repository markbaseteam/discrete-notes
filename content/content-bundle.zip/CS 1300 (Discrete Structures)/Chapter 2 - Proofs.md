## Introduction

###### Chapter 2: Proofs
- 2.1: [[Chapter 2 - Proofs#2.1 Mathematical definitions|Mathematical Definitions]]
- 2.2 [[Chapter 2 - Proofs#2.1 Introduction to Proofs | Introduction to Proofs]]
- 2.3 [[Chapter 2 - Proofs#2.3 Best practices and common errors in proofs | Best practices and common errors in proofs]]
- 2.4 [[Chapter 2 - Proofs#2.4 Writing direct proofs | Writing direct proofs]]
---

# 2.1 Mathematical definitions

#### Even and Odd Integers

Some of the theorems proven in this material are facts about even and odd integers. Although you may have a good understanding of whether an integer is odd or even, a formal mathematical definition provides an algebraic expression for odd or even numbers that can be used in proofs to establish that related integers are even or odd.

![[Screenshot 2023-03-04 at 8.04.28 PM.png]]

![[Screenshot 2023-03-04 at 8.04.41 PM.png]]

---

#### Rational numbers

Some of the theorems proven in this material are facts about rational numbers. A number r is rational if there exist integers x and y such that y ≠ 0 and r = x/y. Note that for a particular rational number r, the choice of x and y is not necessarily unique. For example, if r = .5, then r = 1/2 and r = 2/4.

---

#### Divides 

Some of the theorems proven in this material are about where one integer divides another integer. The definition below gives a mathematical expression for an integer n when m divides n. The mathematical expression for n can then be used to prove related facts about n and m.

![[Screenshot 2023-03-04 at 8.10.12 PM.png]]

---

#### Prime and composite numbers

![[Screenshot 2023-03-04 at 8.13.01 PM.png]]

---

#### Inequalities

![[Screenshot 2023-03-04 at 8.20.15 PM.png]]

---

#### Negating inequalities 

![[Screenshot 2023-03-04 at 8.24.09 PM.png]]

---

# 2.1 Introduction to Proofs

![[Screenshot 2023-03-04 at 8.47.50 PM.png]]

---

###### Example 1

![[Screenshot 2023-03-04 at 8.49.56 PM.png]]

---

#### Theorems that are universal or existential statements

![[Screenshot 2023-03-04 at 8.52.56 PM.png]]

---

#### Proofs of universal statements: proofs by exhaustion

![[Screenshot 2023-03-04 at 8.55.23 PM.png]]

---

#### Proofs of universal statements: universal generalization

![[Screenshot 2023-03-04 at 8.57.36 PM.png]]

---

#### Counterexamples

![[Screenshot 2023-03-04 at 9.00.45 PM.png]]

---
#### Counterexamples for conditional statements

![[Screenshot 2023-03-04 at 9.04.11 PM.png]]

---

#### Proving existential statements

![[Screenshot 2023-03-04 at 9.08.14 PM.png]]

---

#### Disproving existential statements

![[Screenshot 2023-03-04 at 9.10.20 PM.png]]

---

# 2.3 Best practices and common errors in proofs

Most mathematical proofs make use of other facts that are assumed to be true. It is natural to ask what facts can be assumed to be true in writing proofs. A related question is how much detail should be provided in explaining how one step in a proof follows from previous steps. The answer to these questions depend on the intended audience. A proof written by a mathematician intended for publication in a journal that will be read by other mathematicians may assume facts that are inappropriate to assume in a proof to be read by students. If the reader is advanced, then small steps can be skipped under the assumption that the reader can fill in the details on his or her own. This material assumes a novice reader and tends to provide full explanations of each step. It is also good practice in first learning to write proofs to provide detailed arguments at each step.

The proofs in this material are limited to the assumptions listed below. In addition, each step of a proof should apply at most one rule of algebra at a time so that the reader can follow the logic of the proof step by step. Sometimes a mathematical proof will make use of a fact or theorem that has been proven elsewhere. It is always important to provide a clear reference when using outside facts. It is up to your instructor as to whether you can make use of facts proven in this material or other exercises in writing your own proofs. The proofs in this material are for the most part self-contained in that the proofs only make use of the assumptions listed below.

![[Screenshot 2023-03-04 at 10.02.30 PM.png]]

---

#### The language of proofs

Every step in a proof requires justification. The reader needs to know if an assertion follows from an assumption of the proof, a definition, or a previously proven fact. The list below gives some common keywords and phrases that are used to explain the reasoning in a proof. In general, there are many different ways to write a valid proof of a theorem. Proofs can vary in notation or word choice, so the writer often has more than one option in selecting the specific words to be used in a proof.

![[Screenshot 2023-03-04 at 10.05.38 PM.png]]

---

#### Best practices in writing proofs

![[Screenshot 2023-03-04 at 10.12.31 PM.png]]

---

###### Proof example using best practices.

![[Screenshot 2023-03-04 at 10.16.27 PM.png]]

---

#### Existential instantiation

![[Screenshot 2023-03-04 at 10.20.53 PM.png]]

---

#### Common mistakes in proofs

![[Screenshot 2023-03-04 at 10.22.58 PM.png]]

![[Screenshot 2023-03-04 at 10.23.31 PM.png]]

![[Screenshot 2023-03-04 at 10.23.48 PM.png]]

![[Screenshot 2023-03-04 at 10.23.56 PM.png]]

---

# 2.4 Writing direct proofs

![[Screenshot 2023-03-04 at 10.26.35 PM.png]]

---

#### Writing direct proofs

![[Screenshot 2023-03-04 at 10.32.05 PM.png]]

![[Screenshot 2023-03-04 at 10.35.14 PM.png]]

---

###### Example 1

![[Screenshot 2023-03-04 at 10.40.16 PM.png]]

---

#### The process of writing proofs

![[Screenshot 2023-03-04 at 10.41.35 PM.png]]

---

###### Video Example

<iframe width="560" height="315" src="https://www.youtube.com/embed/5wLoO4QpE1w" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

---

![[Screenshot 2023-03-04 at 10.43.46 PM.png]]

---

#### A direct proof about rational numbers

![[Screenshot 2023-03-04 at 10.47.20 PM.png]]

![[Screenshot 2023-03-04 at 10.49.35 PM.png]]

---

###### Homework

[[2.4 Exercises]]

---

# 2.5 Proof by contrapositive

![[Screenshot 2023-03-10 at 8.09.57 PM.png]]

---

![[Screenshot 2023-03-10 at 8.36.05 PM.png]]

---

# 2.6 Proof by contradiction

![[Screenshot 2023-03-10 at 9.33.08 PM.png]]

---

![[Screenshot 2023-03-10 at 9.35.53 PM.png]]

---

# 2.7 Proof by cases

![[Screenshot 2023-03-11 at 7.31.30 PM.png]]

---

![[Screenshot 2023-03-11 at 7.57.05 PM.png]]
