
## Introduction

---

# 6.1 Introduction to binary relations

![[Screenshot 2023-04-08 at 5.49.58 PM.png]]

---

###### Example 1

![[Screenshot 2023-04-08 at 5.54.04 PM.png]]

---

A **matrix representation** of relation R between A and B is a rectangular array of numbers with |A| rows and |B| columns. 

Each row corresponds to an element of A and each column corresponds to an element of B. 

For a ∈ A and b ∈ B, there is a 1 in row a, column b, if aRb. Otherwise, there is a 0.

![[Screenshot 2023-04-08 at 5.55.43 PM.png]]

---

It is possible to have a relation between two sets A and B in which A = B.

A binary relation on a set A is a subset of A x A. The set A is called the domain of the binary relation.

---

###### Arrow diagram for a relation on a finite set

![[Screenshot 2023-04-08 at 6.00.51 PM.png]]

---

# 6.2 Properties of binary relations 


![[Screenshot 2023-04-08 at 6.14.12 PM.png]]

---

#### Reflexive and anti-reflexive binary relations

![[Screenshot 2023-04-08 at 6.23.58 PM.png]]

---

#### Symmetric binary relations

![[Screenshot 2023-04-08 at 6.29.25 PM.png]]

![[Screenshot 2023-04-08 at 6.30.43 PM.png]]

---

#### Anti-symmetric binary relations

![[Screenshot 2023-04-08 at 6.34.19 PM.png]]

![[Screenshot 2023-04-08 at 6.36.50 PM.png]]

---

#### Transitive binary relations

![[Screenshot 2023-04-08 at 6.40.00 PM.png]]

![[Screenshot 2023-04-08 at 6.41.43 PM.png]]



