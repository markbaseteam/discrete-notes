---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
2.4.4

b)

Solution: 

False.

Proof: Consider integers 3 and 5.
Where 3 + 5 = 8 is even, but both 3 and 5 are odd.
So this pair of integers serve as a counterexample ■ ^hIja9ueu

1.13.5 
(these type of question on exam)

a)

A(x): x received an A.
H(x): x is on honor roll.
D(x): x got a detention

The argument can be written as 

∀x H(x) -> A(x)
¬∃x (D(x) ^ A(x))

∴ ¬∃x (D(x) ∧ H(x))

Proof:

3) ∀x ¬(D(x) ^ A(x))       2) De. Morgan
4) ∀x (¬D(x) v ¬A(x))      3) De. Morgan
5) ∀x ¬H(x) v A(x)         conditional
6) ∀x (¬D(x) v ¬H(x))      4), 5) resolution
7) ¬∃x ¬(¬D(x) v ¬H(x))    6) D.M
8) ¬∃x (D(x) ^ H(x))       7) D.M double Negation



e) 

Define:
M(x): x missed a class
D(x): got detention 
A(x) ... A
p: Penelope;

The argument in logic expression form 
∀x ((M(x) ∨ D(x)) → ¬A(x))
p is a particular element (in the domain)
A(p)

∴ ¬D(p)

Proof: 

((M(p) v D(p)) -> ¬A(p))    univ. instant.
¬(M(p) v D(0))             Modus tollens
¬M(p) ^ ¬D(p)              d.m
¬D(p)                      simpl.
■ ^Ro83rISB

2.4.4

a) If x and y are even integers, then x + y is an even integer

Solution: 

∀x ∀y (x is even) ^ (y is even) -> (x+y is even)

Proof: 
x is even so ∃k ∈ I such that x = 2k
y is even so ∃j ∈ I such that y = 2j

x + y = 2k + 2j
= 2(k+j)

Since k and j ∈ I, k+j ∈ I by the closure properties of I on addition 
So x+y is even by definition ■ ^W8TOR6fb

1.13.1

a) 

Define:

H(x): x practices hard.
B(x): x plays badly

The argument in logic form:
1) ∀x (H(x) v B(x))
2) ∃x ¬H(x)

∃x B(x)

(There exist a particular element c) ^ ¬H(c)    Ex. Instant
H(c) v B(c)                                     Univ instant
B(c)                                            disjunctive syll.
∃x B(x)                                         Exist. general
■
 ^jZoIVALu

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.18",
	"elements": [
		{
			"type": "rectangle",
			"version": 81,
			"versionNonce": 2064513378,
			"isDeleted": false,
			"id": "7C970mPDj9tkGmhNL2LEq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -145,
			"y": -145,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 701,
			"height": 490,
			"seed": 885681516,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "W8TOR6fb",
					"type": "text"
				}
			],
			"updated": 1678385170308,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 546,
			"versionNonce": 2146583998,
			"isDeleted": false,
			"id": "W8TOR6fb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -140,
			"y": -104,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 690.9263916015625,
			"height": 408,
			"seed": 1568493676,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678385170308,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "2.4.4\n\na) If x and y are even integers, then x + y is an even integer\n\nSolution: \n\n∀x ∀y (x is even) ^ (y is even) -> (x+y is even)\n\nProof: \nx is even so ∃k ∈ I such that x = 2k\ny is even so ∃j ∈ I such that y = 2j\n\nx + y = 2k + 2j\n= 2(k+j)\n\nSince k and j ∈ I, k+j ∈ I by the closure properties of I on addition \nSo x+y is even by definition ■",
			"rawText": "2.4.4\n\na) If x and y are even integers, then x + y is an even integer\n\nSolution: \n\n∀x ∀y (x is even) ^ (y is even) -> (x+y is even)\n\nProof: \nx is even so ∃k ∈ I such that x = 2k\ny is even so ∃j ∈ I such that y = 2j\n\nx + y = 2k + 2j\n= 2(k+j)\n\nSince k and j ∈ I, k+j ∈ I by the closure properties of I on addition \nSo x+y is even by definition ■",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": "7C970mPDj9tkGmhNL2LEq",
			"originalText": "2.4.4\n\na) If x and y are even integers, then x + y is an even integer\n\nSolution: \n\n∀x ∀y (x is even) ^ (y is even) -> (x+y is even)\n\nProof: \nx is even so ∃k ∈ I such that x = 2k\ny is even so ∃j ∈ I such that y = 2j\n\nx + y = 2k + 2j\n= 2(k+j)\n\nSince k and j ∈ I, k+j ∈ I by the closure properties of I on addition \nSo x+y is even by definition ■"
		},
		{
			"type": "rectangle",
			"version": 362,
			"versionNonce": 1649547518,
			"isDeleted": false,
			"id": "ZFQQd2cx9ZNaiEuwqql1Z",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 580,
			"y": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 600,
			"height": 342,
			"seed": 573680212,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678385177111,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 555,
			"versionNonce": 909540834,
			"isDeleted": false,
			"id": "hIja9ueu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 585,
			"y": 39,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 530.9396362304688,
			"height": 264,
			"seed": 288751956,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678385177111,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "2.4.4\n\nb)\n\nSolution: \n\nFalse.\n\nProof: Consider integers 3 and 5.\nWhere 3 + 5 = 8 is even, but both 3 and 5 are odd.\nSo this pair of integers serve as a counterexample ■",
			"rawText": "2.4.4\n\nb)\n\nSolution: \n\nFalse.\n\nProof: Consider integers 3 and 5.\nWhere 3 + 5 = 8 is even, but both 3 and 5 are odd.\nSo this pair of integers serve as a counterexample ■",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": null,
			"originalText": "2.4.4\n\nb)\n\nSolution: \n\nFalse.\n\nProof: Consider integers 3 and 5.\nWhere 3 + 5 = 8 is even, but both 3 and 5 are odd.\nSo this pair of integers serve as a counterexample ■"
		},
		{
			"type": "rectangle",
			"version": 91,
			"versionNonce": 1212256418,
			"isDeleted": false,
			"id": "JQR3TbD9GsbSLXrvaaLcb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -140,
			"y": 360,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 520,
			"height": 1426,
			"seed": 2130752364,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "Ro83rISB",
					"type": "text"
				}
			],
			"updated": 1678385246893,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1553,
			"versionNonce": 47628926,
			"isDeleted": false,
			"id": "Ro83rISB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -135,
			"y": 485,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 497.63653564453125,
			"height": 1176,
			"seed": 1025343060,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678385246893,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "1.13.5 \n(these type of question on exam)\n\na)\n\nA(x): x received an A.\nH(x): x is on honor roll.\nD(x): x got a detention\n\nThe argument can be written as \n\n∀x H(x) -> A(x)\n¬∃x (D(x) ^ A(x))\n\n∴ ¬∃x (D(x) ∧ H(x))\n\nProof:\n\n3) ∀x ¬(D(x) ^ A(x))       2) De. Morgan\n4) ∀x (¬D(x) v ¬A(x))      3) De. Morgan\n5) ∀x ¬H(x) v A(x)         conditional\n6) ∀x (¬D(x) v ¬H(x))      4), 5) resolution\n7) ¬∃x ¬(¬D(x) v ¬H(x))    6) D.M\n8) ¬∃x (D(x) ^ H(x))       7) D.M double Negation\n\n\n\ne) \n\nDefine:\nM(x): x missed a class\nD(x): got detention \nA(x) ... A\np: Penelope;\n\nThe argument in logic expression form \n∀x ((M(x) ∨ D(x)) → ¬A(x))\np is a particular element (in the domain)\nA(p)\n\n∴ ¬D(p)\n\nProof: \n\n((M(p) v D(p)) -> ¬A(p))    univ. instant.\n¬(M(p) v D(0))             Modus tollens\n¬M(p) ^ ¬D(p)              d.m\n¬D(p)                      simpl.\n■",
			"rawText": "1.13.5 \n(these type of question on exam)\n\na)\n\nA(x): x received an A.\nH(x): x is on honor roll.\nD(x): x got a detention\n\nThe argument can be written as \n\n∀x H(x) -> A(x)\n¬∃x (D(x) ^ A(x))\n\n∴ ¬∃x (D(x) ∧ H(x))\n\nProof:\n\n3) ∀x ¬(D(x) ^ A(x))       2) De. Morgan\n4) ∀x (¬D(x) v ¬A(x))      3) De. Morgan\n5) ∀x ¬H(x) v A(x)         conditional\n6) ∀x (¬D(x) v ¬H(x))      4), 5) resolution\n7) ¬∃x ¬(¬D(x) v ¬H(x))    6) D.M\n8) ¬∃x (D(x) ^ H(x))       7) D.M double Negation\n\n\n\ne) \n\nDefine:\nM(x): x missed a class\nD(x): got detention \nA(x) ... A\np: Penelope;\n\nThe argument in logic expression form \n∀x ((M(x) ∨ D(x)) → ¬A(x))\np is a particular element (in the domain)\nA(p)\n\n∴ ¬D(p)\n\nProof: \n\n((M(p) v D(p)) -> ¬A(p))    univ. instant.\n¬(M(p) v D(0))             Modus tollens\n¬M(p) ^ ¬D(p)              d.m\n¬D(p)                      simpl.\n■",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": "JQR3TbD9GsbSLXrvaaLcb",
			"originalText": "1.13.5 \n(these type of question on exam)\n\na)\n\nA(x): x received an A.\nH(x): x is on honor roll.\nD(x): x got a detention\n\nThe argument can be written as \n\n∀x H(x) -> A(x)\n¬∃x (D(x) ^ A(x))\n\n∴ ¬∃x (D(x) ∧ H(x))\n\nProof:\n\n3) ∀x ¬(D(x) ^ A(x))       2) De. Morgan\n4) ∀x (¬D(x) v ¬A(x))      3) De. Morgan\n5) ∀x ¬H(x) v A(x)         conditional\n6) ∀x (¬D(x) v ¬H(x))      4), 5) resolution\n7) ¬∃x ¬(¬D(x) v ¬H(x))    6) D.M\n8) ¬∃x (D(x) ^ H(x))       7) D.M double Negation\n\n\n\ne) \n\nDefine:\nM(x): x missed a class\nD(x): got detention \nA(x) ... A\np: Penelope;\n\nThe argument in logic expression form \n∀x ((M(x) ∨ D(x)) → ¬A(x))\np is a particular element (in the domain)\nA(p)\n\n∴ ¬D(p)\n\nProof: \n\n((M(p) v D(p)) -> ¬A(p))    univ. instant.\n¬(M(p) v D(0))             Modus tollens\n¬M(p) ^ ¬D(p)              d.m\n¬D(p)                      simpl.\n■"
		},
		{
			"type": "line",
			"version": 135,
			"versionNonce": 587537570,
			"isDeleted": false,
			"id": "jHywM-5uJSsKOhuxT5V11",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -140,
			"y": 680,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 180.94633674770594,
			"height": 0.8882139926455466,
			"seed": 77279956,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1678385170308,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					180.94633674770594,
					0.8882139926455466
				],
				[
					180.94633674770594,
					0.8882139926455466
				]
			]
		},
		{
			"type": "line",
			"version": 56,
			"versionNonce": 1356985982,
			"isDeleted": false,
			"id": "kevP85A9AVQnaUTy3S_4g",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 120.82350458577275,
			"y": 901.774227656424,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 160,
			"seed": 1581129044,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678385170308,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0,
					160
				]
			]
		},
		{
			"type": "line",
			"version": 59,
			"versionNonce": 524105826,
			"isDeleted": false,
			"id": "B_TYXqRfHTg1oh3dZhDpY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -139.83250293985796,
			"y": 1101.4991912255623,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 519.8325029398579,
			"height": 1.4991912255622992,
			"seed": 898932332,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678385170308,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					519.8325029398579,
					-1.4991912255622992
				]
			]
		},
		{
			"type": "line",
			"version": 62,
			"versionNonce": 1754953406,
			"isDeleted": false,
			"id": "dbDlSdyoE_heWpkyRMOW6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -139.48792082729727,
			"y": 1440.8613328590793,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 400,
			"height": 0,
			"seed": 228309332,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678385170308,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					400,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 33,
			"versionNonce": 1568398370,
			"isDeleted": false,
			"id": "t01wFA561JzW5jllJTFgN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 120.30057714520726,
			"y": 1520.897150553763,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 120,
			"seed": 551934292,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678385170308,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0,
					120
				]
			]
		},
		{
			"type": "rectangle",
			"version": 122,
			"versionNonce": 769191678,
			"isDeleted": false,
			"id": "76MwNNjq9ZDu55euuMRcZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 400,
			"y": 360,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 637,
			"height": 514,
			"seed": 737948990,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "jZoIVALu",
					"type": "text"
				}
			],
			"updated": 1678385170308,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 641,
			"versionNonce": 1806698466,
			"isDeleted": false,
			"id": "jZoIVALu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 405,
			"y": 365,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 626.8797607421875,
			"height": 504,
			"seed": 454847700,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678385170308,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "1.13.1\n\na) \n\nDefine:\n\nH(x): x practices hard.\nB(x): x plays badly\n\nThe argument in logic form:\n1) ∀x (H(x) v B(x))\n2) ∃x ¬H(x)\n\n∃x B(x)\n\n(There exist a particular element c) ^ ¬H(c)    Ex. Instant\nH(c) v B(c)                                     Univ instant\nB(c)                                            disjunctive syll.\n∃x B(x)                                         Exist. general\n■\n",
			"rawText": "1.13.1\n\na) \n\nDefine:\n\nH(x): x practices hard.\nB(x): x plays badly\n\nThe argument in logic form:\n1) ∀x (H(x) v B(x))\n2) ∃x ¬H(x)\n\n∃x B(x)\n\n(There exist a particular element c) ^ ¬H(c)    Ex. Instant\nH(c) v B(c)                                     Univ instant\nB(c)                                            disjunctive syll.\n∃x B(x)                                         Exist. general\n■\n",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": "76MwNNjq9ZDu55euuMRcZ",
			"originalText": "1.13.1\n\na) \n\nDefine:\n\nH(x): x practices hard.\nB(x): x plays badly\n\nThe argument in logic form:\n1) ∀x (H(x) v B(x))\n2) ∃x ¬H(x)\n\n∃x B(x)\n\n(There exist a particular element c) ^ ¬H(c)    Ex. Instant\nH(c) v B(c)                                     Univ instant\nB(c)                                            disjunctive syll.\n∃x B(x)                                         Exist. general\n■\n"
		},
		{
			"type": "line",
			"version": 85,
			"versionNonce": 1830707006,
			"isDeleted": false,
			"id": "HVgv30iSyzEHbYSGe8z7Y",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 400.70585554198476,
			"y": 660.5804511470341,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 300,
			"height": 0,
			"seed": 148055148,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678385170308,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					300,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 69,
			"versionNonce": 1105771426,
			"isDeleted": false,
			"id": "CtVA3cwkbktqbQjRUynZ7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 861.3578992709517,
			"y": 700.2650204114616,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 140,
			"seed": 1457650644,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678385170308,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0,
					140
				]
			]
		},
		{
			"id": "LHRU7pOU",
			"type": "text",
			"x": 576.2899569099573,
			"y": 1147.6655257547468,
			"width": 10,
			"height": 24,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1442485118,
			"version": 2,
			"versionNonce": 189328226,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1678391208138,
			"link": null,
			"locked": false,
			"text": "",
			"rawText": "",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": ""
		},
		{
			"type": "line",
			"version": 575,
			"versionNonce": 1773188478,
			"isDeleted": true,
			"id": "h2xGF-f5E_bOBCBvnyrfK",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 5.497787143782138,
			"x": 551.4968516757904,
			"y": 1121.119065891171,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 57.92592404293865,
			"height": 0.05683201435823548,
			"seed": 825117694,
			"groupIds": [
				"k5rydkUVEAYU0XEmR5Ccl"
			],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391219983,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					57.92592404293865,
					-0.05683201435823548
				]
			]
		},
		{
			"type": "line",
			"version": 659,
			"versionNonce": 1325263202,
			"isDeleted": true,
			"id": "sdMRzWJ_G3a-VWuIIuC2U",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 600.9571104590719,
			"y": 1100,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 87.3043690557065,
			"height": 0,
			"seed": 2024471266,
			"groupIds": [
				"hnp1c5iih11FDQF3oscw7",
				"k5rydkUVEAYU0XEmR5Ccl"
			],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391219983,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					87.3043690557065,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 706,
			"versionNonce": 389633470,
			"isDeleted": true,
			"id": "HEWa3VUt20v_PB-DSUOJ7",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 601.3049312386236,
			"y": 1187.3043690557065,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 87.3043690557065,
			"height": 0,
			"seed": 2009078846,
			"groupIds": [
				"hnp1c5iih11FDQF3oscw7",
				"k5rydkUVEAYU0XEmR5Ccl"
			],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391219983,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					87.3043690557065,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 725,
			"versionNonce": 335441186,
			"isDeleted": true,
			"id": "WOyx2J4dM45btuI09QLJC",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 1.5707963267948957,
			"x": 557.6527467107703,
			"y": 1143.6521845278533,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 87.3043690557065,
			"height": 0,
			"seed": 2030915234,
			"groupIds": [
				"hnp1c5iih11FDQF3oscw7",
				"k5rydkUVEAYU0XEmR5Ccl"
			],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391219983,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					87.3043690557065,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 777,
			"versionNonce": 54783486,
			"isDeleted": true,
			"id": "5BkD7aMDl5QRWjgr2TeRJ",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 1.5707963267948957,
			"x": 644.6092949869252,
			"y": 1143.6521845278533,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 87.3043690557065,
			"height": 0,
			"seed": 1680729214,
			"groupIds": [
				"hnp1c5iih11FDQF3oscw7",
				"k5rydkUVEAYU0XEmR5Ccl"
			],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391219983,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					87.3043690557065,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 493,
			"versionNonce": 901282018,
			"isDeleted": true,
			"id": "1uaTwx3HiUIAvB7OUypAk",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 5.497787143782138,
			"x": 639.559263908562,
			"y": 1121.9323481971555,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 55.47093230622323,
			"height": 0.31660337367254243,
			"seed": 695151202,
			"groupIds": [
				"k5rydkUVEAYU0XEmR5Ccl"
			],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391219983,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					55.47093230622323,
					0.31660337367254243
				]
			]
		},
		{
			"type": "line",
			"version": 692,
			"versionNonce": 2060549694,
			"isDeleted": true,
			"id": "_9586UZqPVnOQv5kYlzPN",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 5.497787143782138,
			"x": 638.8468748246056,
			"y": 1208.3132162161144,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 58.146361504464686,
			"height": 0.16360544716780367,
			"seed": 1211671742,
			"groupIds": [
				"k5rydkUVEAYU0XEmR5Ccl"
			],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391219983,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					58.146361504464686,
					0.16360544716780367
				]
			]
		},
		{
			"type": "line",
			"version": 561,
			"versionNonce": 1941638306,
			"isDeleted": true,
			"id": "rXpJoy7kyAlPl9m9LTwY5",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 5.497787143782138,
			"x": 551.6103096158247,
			"y": 1207.9892368925548,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 59.20853371395714,
			"height": 0.18843590571283642,
			"seed": 1889504802,
			"groupIds": [
				"k5rydkUVEAYU0XEmR5Ccl"
			],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391219983,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					59.20853371395714,
					-0.18843590571283642
				]
			]
		},
		{
			"type": "line",
			"version": 49,
			"versionNonce": 46335614,
			"isDeleted": true,
			"id": "zr-e87jIWsHWwh1d-liEh",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 560,
			"y": 1141.590649883992,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 87.3043690557065,
			"height": 0,
			"seed": 360799486,
			"groupIds": [
				"k5rydkUVEAYU0XEmR5Ccl"
			],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391219983,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					87.3043690557065,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 81,
			"versionNonce": 1135945826,
			"isDeleted": true,
			"id": "BKybzUxcyjtSchXz0wGUb",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 560.3478207795516,
			"y": 1228.8950189396983,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 87.3043690557065,
			"height": 0,
			"seed": 59603426,
			"groupIds": [
				"k5rydkUVEAYU0XEmR5Ccl"
			],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391219983,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					87.3043690557065,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 100,
			"versionNonce": 1540982462,
			"isDeleted": true,
			"id": "YQKQJZzkYnZDvHe4_3p_L",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 1.5707963267948957,
			"x": 516.6956362516984,
			"y": 1185.2428344118453,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 87.3043690557065,
			"height": 0,
			"seed": 1636371774,
			"groupIds": [
				"k5rydkUVEAYU0XEmR5Ccl"
			],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391219983,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					87.3043690557065,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 154,
			"versionNonce": 225823778,
			"isDeleted": true,
			"id": "iEjFP90Ji7arvf3DT8VSD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 1.5707963267948957,
			"x": 603.6521845278533,
			"y": 1185.2428344118453,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 87.3043690557065,
			"height": 0,
			"seed": 558362018,
			"groupIds": [
				"k5rydkUVEAYU0XEmR5Ccl"
			],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391219983,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					87.3043690557065,
					0
				]
			]
		},
		{
			"type": "ellipse",
			"version": 1197,
			"versionNonce": 185616034,
			"isDeleted": true,
			"id": "03d6Khbk68YpFrsMeEx8D",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 602.2758472725964,
			"y": 1020,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.63068501487636,
			"height": 42.15167874318576,
			"seed": 112590590,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1204,
			"versionNonce": 569797758,
			"isDeleted": true,
			"id": "rHJZ9YxLM5mOjDGwBxgAI",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 488.8800602271158,
			"y": 1088.5549001861946,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.63068501487636,
			"height": 42.15167874318576,
			"seed": 1726740450,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1282,
			"versionNonce": 1884496482,
			"isDeleted": true,
			"id": "b80MPm2Avu0kdDm5r2TDx",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 430.68298983232853,
			"y": 1157.9371157886762,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.63068501487636,
			"height": 42.15167874318576,
			"seed": 1205432126,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1399,
			"versionNonce": 1269836990,
			"isDeleted": true,
			"id": "YzeBtribz465H2Qn5QFpe",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 547.0942037493078,
			"y": 1157.9371157886762,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.63068501487636,
			"height": 42.15167874318576,
			"seed": 1344711586,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1302,
			"versionNonce": 675579426,
			"isDeleted": true,
			"id": "U7fHhX8Gcsh5_7_zpwGFf",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 720.8285974099026,
			"y": 1088.5549001861946,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.63068501487636,
			"height": 42.15167874318576,
			"seed": 732223358,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1300,
			"versionNonce": 1355277566,
			"isDeleted": true,
			"id": "UiVPzdtKdiVCNUU8Hkq7H",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 662.3307035180351,
			"y": 1157.9371157886762,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.63068501487636,
			"height": 42.15167874318576,
			"seed": 1867835234,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1478,
			"versionNonce": 1809019362,
			"isDeleted": true,
			"id": "ZFdBa-78J_3pdvQv8tsIZ",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 777.5672032867697,
			"y": 1157.9371157886762,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.63068501487636,
			"height": 42.15167874318576,
			"seed": 173619134,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1356,
			"versionNonce": 46044478,
			"isDeleted": true,
			"id": "nC0Xvb__XvYycKDvzzu7-",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 400,
			"y": 1241.9757393416821,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.63068501487636,
			"height": 42.15167874318576,
			"seed": 1288022818,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1546,
			"versionNonce": 2114905506,
			"isDeleted": true,
			"id": "O9fPVapD64JQbJzBzdkci",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 458.52668449052544,
			"y": 1241.9757393416821,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.63068501487636,
			"height": 42.15167874318576,
			"seed": 202870782,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1384,
			"versionNonce": 1526021502,
			"isDeleted": true,
			"id": "IR3FBl8WNcSZAjXMCMJ63",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 517.0533689810518,
			"y": 1241.9757393416821,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.63068501487636,
			"height": 42.15167874318576,
			"seed": 250083042,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1574,
			"versionNonce": 1747312994,
			"isDeleted": true,
			"id": "0Zbuv1o-3bF28Rtqb8x4u",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 575.5800534715927,
			"y": 1241.9757393416821,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.63068501487636,
			"height": 42.15167874318576,
			"seed": 752934974,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1391,
			"versionNonce": 2125258174,
			"isDeleted": true,
			"id": "HfWUNzDxeWJ2QwxS0FANH",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 634.10673796213,
			"y": 1241.9757393416821,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.63068501487636,
			"height": 42.15167874318576,
			"seed": 910871202,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1581,
			"versionNonce": 895968546,
			"isDeleted": true,
			"id": "cCIgA0avyDlhq9C79v5MP",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 692.6334224526581,
			"y": 1241.9757393416821,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.63068501487636,
			"height": 42.15167874318576,
			"seed": 1083582590,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1391,
			"versionNonce": 1124496894,
			"isDeleted": true,
			"id": "o4lsKuq61h6Cx4EGLsyLV",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 751.1601069431799,
			"y": 1241.9757393416821,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.63068501487636,
			"height": 42.15167874318576,
			"seed": 1503471202,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1581,
			"versionNonce": 792883426,
			"isDeleted": true,
			"id": "5TVPbWS-8dQ3GAr1FtZok",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 809.6867914337063,
			"y": 1241.9757393416821,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.63068501487636,
			"height": 42.15167874318576,
			"seed": 1995991230,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 1523,
			"versionNonce": 822281790,
			"isDeleted": true,
			"id": "yGgkiFtUCOXUzqTTBJiOl",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 604.1899267488297,
			"y": 1051.671662532986,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 76.14586824448608,
			"height": 43.319769206567784,
			"seed": 1638795810,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false,
			"startBinding": {
				"focus": 0.029687209192477727,
				"gap": 1,
				"elementId": "03d6Khbk68YpFrsMeEx8D"
			},
			"endBinding": {
				"focus": -0.19500628179428073,
				"gap": 1.2007858709866923,
				"elementId": "rHJZ9YxLM5mOjDGwBxgAI"
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-76.14586824448608,
					43.319769206567784
				]
			]
		},
		{
			"type": "arrow",
			"version": 1457,
			"versionNonce": 424019106,
			"isDeleted": true,
			"id": "i-XJTM9617I11t-jGbvKZ",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 643.8077178864828,
			"y": 1051.9901189008551,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 78.50908852267256,
			"height": 45.661408297506355,
			"seed": 1604886782,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false,
			"startBinding": {
				"focus": -0.02247876193187343,
				"gap": 1,
				"elementId": "03d6Khbk68YpFrsMeEx8D"
			},
			"endBinding": {
				"focus": 0.006374565137878445,
				"gap": 1.9762151918654176,
				"elementId": "U7fHhX8Gcsh5_7_zpwGFf"
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					78.50908852267256,
					45.661408297506355
				]
			]
		},
		{
			"type": "arrow",
			"version": 1215,
			"versionNonce": 159616638,
			"isDeleted": true,
			"id": "LHgs7F4K1uPgpVDf00IcU",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 725.3054174160361,
			"y": 1126.841573509159,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28.208138747425267,
			"height": 35.0634949465878,
			"seed": 1164735970,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false,
			"startBinding": {
				"focus": 0.12640921310317504,
				"gap": 2.9899298573061692,
				"elementId": "U7fHhX8Gcsh5_7_zpwGFf"
			},
			"endBinding": {
				"focus": -0.029383302112538794,
				"gap": 1,
				"elementId": "UiVPzdtKdiVCNUU8Hkq7H"
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-28.208138747425267,
					35.0634949465878
				]
			]
		},
		{
			"type": "arrow",
			"version": 1284,
			"versionNonce": 1830887522,
			"isDeleted": true,
			"id": "hWyOs0_5DoeX7i8vc-ntL",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 758.9613965862645,
			"y": 1125.3114816834527,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 31.7998445622841,
			"height": 34.73977782895246,
			"seed": 1848103230,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false,
			"startBinding": {
				"focus": -0.06743090091507659,
				"gap": 1.1792141946122001,
				"elementId": "U7fHhX8Gcsh5_7_zpwGFf"
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					31.7998445622841,
					34.73977782895246
				]
			]
		},
		{
			"type": "arrow",
			"version": 1372,
			"versionNonce": 1229524670,
			"isDeleted": true,
			"id": "qYPUaFZ4ML0f71QlO0luw",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 674.740735262697,
			"y": 1199.8596356786697,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 13.681195653648501,
			"height": 40.70100089283096,
			"seed": 1172793762,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1678391226467,
			"link": null,
			"locked": false,
			"startBinding": {
				"focus": 0.10454485943214174,
				"gap": 1.6740233958445252,
				"elementId": "UiVPzdtKdiVCNUU8Hkq7H"
			},
			"endBinding": {
				"focus": -0.10562161162611655,
				"gap": 1.959295753811002,
				"elementId": "HfWUNzDxeWJ2QwxS0FANH"
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-13.681195653648501,
					40.70100089283096
				]
			]
		},
		{
			"type": "arrow",
			"version": 1351,
			"versionNonce": 379765794,
			"isDeleted": true,
			"id": "j02Mpyl5wmLLCg0hBllUG",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 695.9123919349618,
			"y": 1199.2328641803879,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 12.602976144995864,
			"height": 42.60517718712663,
			"seed": 2111240574,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1678391226468,
			"link": null,
			"locked": false,
			"startBinding": {
				"focus": -0.2549781989218489,
				"gap": 2.137635196918417,
				"elementId": "UiVPzdtKdiVCNUU8Hkq7H"
			},
			"endBinding": {
				"focus": 0.01506252359516849,
				"gap": 1,
				"elementId": "cCIgA0avyDlhq9C79v5MP"
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					12.602976144995864,
					42.60517718712663
				]
			]
		},
		{
			"type": "arrow",
			"version": 1244,
			"versionNonce": 754222846,
			"isDeleted": true,
			"id": "E5cKWA_f6YyOKMyJDlcYU",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 788.7105549747203,
			"y": 1198.0604452873617,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 9.44992007676207,
			"height": 43.60935038040972,
			"seed": 709748066,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1678391226468,
			"link": null,
			"locked": false,
			"startBinding": {
				"focus": 0.29362974767750205,
				"gap": 1,
				"elementId": "ZFdBa-78J_3pdvQv8tsIZ"
			},
			"endBinding": {
				"focus": 0.0741136076378415,
				"gap": 1.1543109452637985,
				"elementId": "o4lsKuq61h6Cx4EGLsyLV"
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-9.44992007676207,
					43.60935038040972
				]
			]
		},
		{
			"type": "arrow",
			"version": 1341,
			"versionNonce": 800714722,
			"isDeleted": true,
			"id": "ZrY1ysR3n1zkPmka6QEb_",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 811.2539554074438,
			"y": 1197.8144332194006,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 15.137033907710029,
			"height": 43.824207531824435,
			"seed": 1442257342,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1678391226468,
			"link": null,
			"locked": false,
			"startBinding": {
				"focus": -0.2338177395149689,
				"gap": 1,
				"elementId": "ZFdBa-78J_3pdvQv8tsIZ"
			},
			"endBinding": {
				"focus": 0.09935516533714739,
				"gap": 1,
				"elementId": "5TVPbWS-8dQ3GAr1FtZok"
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					15.137033907710029,
					43.824207531824435
				]
			]
		},
		{
			"type": "arrow",
			"version": 1306,
			"versionNonce": 889648958,
			"isDeleted": true,
			"id": "x0Tr6Ay5GuGGLiMOAY0xy",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 579.0059221110814,
			"y": 1198.6994136137969,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 11.507454456357186,
			"height": 42.72461949213502,
			"seed": 2079254818,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1678391226468,
			"link": null,
			"locked": false,
			"startBinding": {
				"focus": -0.2126726032055372,
				"gap": 1,
				"elementId": "YzeBtribz465H2Qn5QFpe"
			},
			"endBinding": {
				"focus": -0.04688417376999017,
				"gap": 1.555113048513828,
				"elementId": "0Zbuv1o-3bF28Rtqb8x4u"
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					11.507454456357186,
					42.72461949213502
				]
			]
		},
		{
			"type": "arrow",
			"version": 1383,
			"versionNonce": 1014342562,
			"isDeleted": true,
			"id": "JVGTD_CJmmCJL53Iv4jFd",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 556.8277651616536,
			"y": 1198.3469731102864,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 14.534325584103954,
			"height": 42.45752045553354,
			"seed": 766063102,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1678391226468,
			"link": null,
			"locked": false,
			"startBinding": {
				"focus": 0.2377653301918221,
				"gap": 1.5219946443615484,
				"elementId": "YzeBtribz465H2Qn5QFpe"
			},
			"endBinding": {
				"focus": -0.18239778911032814,
				"gap": 1.4169603306715395,
				"elementId": "IR3FBl8WNcSZAjXMCMJ63"
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-14.534325584103954,
					42.45752045553354
				]
			]
		},
		{
			"type": "arrow",
			"version": 1418,
			"versionNonce": 702635902,
			"isDeleted": true,
			"id": "46ubvVlqu5U4ztPeuglly",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 460.826872047342,
			"y": 1200.2653513034466,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 13.491503495684524,
			"height": 39.292147850777745,
			"seed": 1111061730,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1678391226468,
			"link": null,
			"locked": false,
			"startBinding": {
				"focus": -0.0448669004309337,
				"gap": 1.655688846911847,
				"elementId": "b80MPm2Avu0kdDm5r2TDx"
			},
			"endBinding": {
				"focus": 0.08890264382063708,
				"gap": 3.1343422999896653,
				"elementId": "O9fPVapD64JQbJzBzdkci"
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					13.491503495684524,
					39.292147850777745
				]
			]
		},
		{
			"type": "arrow",
			"version": 1475,
			"versionNonce": 1728372578,
			"isDeleted": true,
			"id": "ogA0SLI8Lk12UaFHsf4Hc",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 441.6183016453674,
			"y": 1198.4299185711852,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 14.145109427996156,
			"height": 43.33778047098872,
			"seed": 804143678,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1678391226468,
			"link": null,
			"locked": false,
			"startBinding": {
				"focus": 0.19858550052599835,
				"gap": 1.0113417636391944,
				"elementId": "b80MPm2Avu0kdDm5r2TDx"
			},
			"endBinding": {
				"focus": -0.05635343922934983,
				"gap": 1,
				"elementId": "nC0Xvb__XvYycKDvzzu7-"
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-14.145109427996156,
					43.33778047098872
				]
			]
		},
		{
			"type": "arrow",
			"version": 1455,
			"versionNonce": 532987838,
			"isDeleted": true,
			"id": "DmzoQLbmwfQHJ1_obIPXd",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 493.0908320335102,
			"y": 1124.6786180647905,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28.91766986347011,
			"height": 35.502859050588995,
			"seed": 1052543138,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1678391226468,
			"link": null,
			"locked": false,
			"startBinding": {
				"focus": 0.1926468635576403,
				"gap": 1.6647629400967148,
				"elementId": "rHJZ9YxLM5mOjDGwBxgAI"
			},
			"endBinding": {
				"focus": -0.13197980874246712,
				"gap": 1,
				"elementId": "b80MPm2Avu0kdDm5r2TDx"
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-28.91766986347011,
					35.502859050588995
				]
			]
		},
		{
			"type": "arrow",
			"version": 1292,
			"versionNonce": 1001825058,
			"isDeleted": true,
			"id": "I7avwhbOnCTB7_ov-PECk",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 526.264290764087,
			"y": 1125.3131830660423,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 29.271873255914215,
			"height": 34.27692100064178,
			"seed": 2141670014,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1678391226468,
			"link": null,
			"locked": false,
			"startBinding": {
				"focus": -0.07695323740114789,
				"gap": 1,
				"elementId": "rHJZ9YxLM5mOjDGwBxgAI"
			},
			"endBinding": {
				"focus": 0.11362081248537337,
				"gap": 2.275199296563393,
				"elementId": "YzeBtribz465H2Qn5QFpe"
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					29.271873255914215,
					34.27692100064178
				]
			]
		},
		{
			"id": "29VyXB0qSLPncA_fqA9yA",
			"type": "ellipse",
			"x": -260,
			"y": -40,
			"width": 60,
			"height": 140,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1694101218,
			"version": 11,
			"versionNonce": 968778146,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1678391233620,
			"link": null,
			"locked": false
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 381.13412157352786,
		"scrollY": 437.9589025730928,
		"zoom": {
			"value": 0.7763086478898268
		},
		"currentItemRoundness": "sharp",
		"gridSize": 20,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%